#include<iostream>
using namespace std;
class ex
{
    int a;
public:
    ex()
    {
        a=10;
        cout<<a<<endl;
        a++;
    }
    ~ex()
    {
        cout<<a<<endl;
        cout<<"object terminated"<<endl;
    }
};
main()
{
    ex ob;
    ex ob1;
}
