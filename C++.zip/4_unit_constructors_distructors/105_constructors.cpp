#include<iostream>
using namespace std;
class example
{
public:
    example()
    {
        cout<<"hello";
    }
};
main()
{
    example ob;

}
