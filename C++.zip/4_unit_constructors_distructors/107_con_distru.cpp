#include<iostream>
using namespace std;
class example
{
public:
    example()
    {
        cout<<"hello"<<endl;
    }
    ~example()
    {
        cout<<"end"<<endl;
    }
};
main()
{
    example ob1;
    cout<<"one"<<endl;
    example ob2;
    cout<<"two"<<endl;
    example ob3;


}


