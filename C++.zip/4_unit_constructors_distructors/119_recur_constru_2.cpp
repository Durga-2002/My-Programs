#include<iostream>
using namespace std;
class example
{
public:
    example(int a,int n)
    {
        if(a==n)
            cout<<a;
        else
        {
            cout<<a;
            example(a+1,n);
        }
    }
};
main()
{
    int n;
    cout<<"enter number:";
    cin>>n;
    example ob(1,n);
}


