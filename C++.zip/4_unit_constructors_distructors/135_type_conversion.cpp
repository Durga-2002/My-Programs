#include<iostream>
#include<stdio.h>
using namespace std;
main()
{
    printf("%f",9/5);
    printf("\n%f",12/5.0);
    printf("\n%d",10/5);
    printf("\n%d",12/5.0);

    cout<<15/10<<endl;
    cout<<char(65/1);
}
