#include<iostream>
using namespace std;
class ex
{
private:
    int a;
public:
    ex(int a)
    {
        this->a=a;
    }
    void operator ++(int n)
    {
        a++;
    }
    void display()
    {
        cout<<a<<endl;
    }
};
main()
{
    ex ob(5);
    ob.display();
    ob++;
    ob.display();
}
