#include<iostream>
using namespace std;
class ex
{
    int real;
    int img;
public:
   ex()
    {
          real=0;
          img=0;
    }
    ex(int real,int img)
    {
        this->real=real;
        this->img=img;
    }
    ex operator +(ex ob)
    {
        ex t;
        t.real=real+ob.real;
        t.img=img+ob.img;
        return t;
    }
    void display()
    {
       cout<<real<<"+i"<<img;
    }
};
main()
{
    ex ob(5,10),ob2(5,4),ob3;
    cout<<"\nfirst number:";
    ob.display();
    cout<<"\nsecond number:";
    ob2.display();
    ob3=ob+ob2;
    cout<<"\nsum:";
    ob3.display();


}

