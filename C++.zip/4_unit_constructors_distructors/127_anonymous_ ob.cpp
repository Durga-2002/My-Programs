#include<iostream>
using namespace std;
class ex
{
    int a;
public:
    ex()
    {
        a=20;
        cout<<a<<endl;
        display();
    }
    void display()
    {
        cout<<this<<a<<endl;
        this->a=3;
        cout<<a<<endl;
    }
};
main()
{
    ex ();
    //ex (ex());
   // this->display();
}

