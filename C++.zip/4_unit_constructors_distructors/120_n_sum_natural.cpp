#include<iostream>
using namespace std;
class example
{
public:
    example(int a,int sum,int n)
    {
        if(a==n)
            cout<<sum+a;
        else
        {
            sum=sum+a;
            example(a+1,sum,n);
        }
    }
};
main()
{
    int n;
    cout<<"enter number:";
    cin>>n;

    example ob(1,0,n);
}


