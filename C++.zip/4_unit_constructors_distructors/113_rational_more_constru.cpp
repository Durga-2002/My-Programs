#include<iostream>
using namespace  std;
class rational
{
private:
    int n,d;
public:
    rational()
    {
        n=0;
         d=1;
    }
    rational(int num)
    {
        n=num;
        d=1;
    }
    rational(int num,int den)
    {
        n=num;
        d=den;
    }

    void print()
    {
        cout<<n<<"/"<<d;
    }
};
main()
{
    rational x,y(7),z(2,5);
    cout<<"x= ";
    x.print();
    cout<<"\ny= ";
    y.print();
    cout<<"\nz= ";
    z.print();
}

