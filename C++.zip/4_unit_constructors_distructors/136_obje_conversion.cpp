#include<iostream>
using namespace std;
class ex
{
    float num;
public:
    ex()
    {
        num=0;
    }
    void print()
    {
        cout<<num<<endl;
    }
    ex(float a)
    {
        num=a;

    }
};
main()
{
    ex ob1,ob2(3.45);
    ob1.print();
    ob1='A';
    ob1.print();
    ob1=2.4;
    ob1.print();
    ob2.print();



}
