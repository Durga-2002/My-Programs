#include<iostream>
using namespace std;
class ex
{
    int a;
public:
   ex()
    {

    }
    ex(int a)
    {
        this->a=a;
    }
    ex operator +(ex ob)
    {
        //ex t;
        a=a+ob.a;
        return a;
    }
    void display()
    {
        cout<<a;
    }
};
main()
{
    ex ob(5),ob2(10),ob3;
    cout<<"\nfirst number:";
    ob.display();
    cout<<"\nsecond number:";
    ob2.display();
    ob3=ob+ob2;
    cout<<"\nsum:";
    ob3.display();


}
