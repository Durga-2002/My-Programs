#include<iostream>
using namespace std;
class one
{
private:
    int a,b;
public:
    one()
    {
        a=1,b=2;
        cout<<"a:"<<a<<"\t"<<"b:"<<b<<endl;
    }
    one(int x)
    {
        a=x;
        b=2;
        cout<<"a:"<<a<<"\t"<<"b:"<<b<<endl;
    }
    one(int x,int y)
    {
        a=x;
        b=y;
        cout<<"a:"<<a<<"\t"<<"b:"<<b<<endl;
    }

};
main()
{
    one ob;
    one ob2(10);
    one ob3(20,30);
}
