#include<iostream>
using namespace std;
class one
{
    int a;
public:
    one()
    {
         a=0;
    }
    one(int a)
    {
     this->a=a;
    }
    friend one operator /(one n1,one n2)
    {
      one n3;
      n3.a=n1.a/n2.a;
      return n3;
    }
    void display()
    {
        cout<<a<<endl;
    }
};
main()
{
    one n1(10),n2(2),n3;
    n1.display();
   n2.display();
    n3=n1/n2;
    n3.display();
}
