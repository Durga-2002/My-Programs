#include<iostream>
using namespace  std;
class rational
{
private:
    int n,d;
public:
    rational(int num,int den)
    {
        n=num;
         d=den;
    }
    void print()
    {
        cout<<n<<"/"<<d;
    }
};
main()
{
    rational x(-1,3),y(5,7);
    cout<<"x= ";
    x.print();
    cout<<"y= ";
    y.print();
}
