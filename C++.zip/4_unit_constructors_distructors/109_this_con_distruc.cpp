#include<iostream>
using namespace std;
class example
{
public:
    example()
    {
        cout<<this<<"is called"<<endl; //this referece to the current object
    }
    ~example()
    {
        cout<<this<<"it terminated."<<endl;
    }
};
main()
{
    example ob1,ob2,ob3;
     cout<<&ob1<<"\t"<<&ob2<<"\t"<<&ob3<<endl;

}


