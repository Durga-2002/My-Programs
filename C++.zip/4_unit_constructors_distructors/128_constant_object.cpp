#include<iostream>
using namespace std;
class ex
{
   int b;
   const int a=70;
public:
    ex()
    {
        b=10;
    }
    void display() //const
    {
        cout<<a<<endl;
        //a=30;
        cout<<a<<endl;
        show();

    }
    void show() const
    {
        cout<<"hello";
    }
};
main()
{
    ex ob;
    ob.display();
}
