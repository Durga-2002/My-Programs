#include<iostream>
using namespace std;
class display
{
private:
    display()
    {
        cout<<"constructor and distructor defined as private."<<endl;
    }
    ~display()
    {
        cout<<"end";
    }
public:
    void display_ex()
    {
        display ob;
        ob.display::~display();
        //display();

    }
};
main()
{
    display *ob;
    ob->display_ex();
}
