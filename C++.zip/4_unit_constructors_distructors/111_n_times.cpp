#include<iostream>
using namespace std;
class ex
{
public:
    ex()
    {
        cout<<"hello"<<endl;
    }
};
main()
{
    ex ob[10];
}
