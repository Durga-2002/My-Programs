#include<iostream>
using namespace std;
class one
{
private:
    int a;
public:
    one(int a)
    {
        this->a=a;
    }
    void operator --()
    {
        --a;
    }
    void display()
    {
        cout<<a<<endl;
    }
};
main()
{
    one ob(5);
    ob.display();
    --ob;
    ob.display();
}
