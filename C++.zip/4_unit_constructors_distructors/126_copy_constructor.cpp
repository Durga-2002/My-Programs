#include<iostream>
using namespace std;
class ex
{
    int a;
public:
    ex()
    {
        a=20;
        cout<<a<<endl;

    }
   ex(ex &ob)
    {
        a=ob.a+5;
        cout<<a<<endl;
        cout<<"hai";
    }
};
main()
{
    ex ob1;
    ex ob2(ob1);
}
