#include<iostream>
using namespace std;
class example
{
public:
    example(int a)
    {
        if(a==5)
            cout<<a;
        else
        {
            cout<<a;
            example(a+1);
        }
    }
};
main()
{
    example ob(1);
}

