#include<iostream>
using namespace std;
class ex
{
    int a;
public:
    ex()
    {
        cout<<"enter value:";
        cin>>a;
        cout<<a<<endl;
    }
};
main()
{
    ex ob;
    ex ob2=ex();
}

