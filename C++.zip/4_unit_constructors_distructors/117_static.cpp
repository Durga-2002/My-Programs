#include<iostream>
using namespace std;
class example
{
 private:
     int a;
     static int b;
 public:
   example()
    {
        a=29;
        a++;
        b++;
        cout<<"a:"<<a<<endl;
        cout<<"b:"<<b;
    }
};
int  example::b=9;
main()
{
    example ob;
}
