#include<iostream>
using namespace std;
class ex
{
private:
    int *p;
public:
    ex()
    {
     p=new int;
    }
    ~ex()
    {
     delete p;
    }
    void read()
    {
     cout<<"enter number:";
     cin>>*p;
    }
    void display()
    {
        cout<<*p;
    }

};
main()
{
    ex ob;
    ob.read();
    ob.display();
}
