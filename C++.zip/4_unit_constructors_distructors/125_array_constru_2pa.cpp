#include<iostream>
using namespace std;
class  test
{
    int a,b;
public:
    test(int x)
    {
        a=x;
    }
    test(int x,int y)
    {
        a=x;
        b=y;
    }
    void display()
    {
        cout<<a<<endl;
    }
     void display_1()
    {
        cout<<a<<b<<endl;
    }
};
main()
{
    test ob[3]={1,test(10,20),3};
    ob[0].display();
    ob[1].display_1();
    ob[2].display();
}

