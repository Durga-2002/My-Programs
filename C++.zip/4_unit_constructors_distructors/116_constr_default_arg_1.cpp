#include<iostream>
using namespace std;
class ex
{
public:
    ex(int a=1,int b=2);
};
ex::ex(int x,int y)
{
    cout<<"two parameters:"<<x+y;

}
int main()
{
ex ob;
ex ob2(10);
ex ob3(10,20);
}
