#include<iostream>
using namespace std;
class ex
{
    int a;
public:
    void display()
    {
        a=50;
    }
    void read()
    {
        this->a=a;
        cout<<a;
    }
};
main()
{
    ex ob1,ob2;
    ob1.display();
    ob2.read();
}
