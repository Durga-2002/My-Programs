#include<iostream>
using namespace std;
class one
{
public:
    one(int x=10,int y=20,int z=30,int p=50)
    {
        cout<<"sum: "<<x+y+z+p<<endl;
    }

};
main()
{
    int a=1,b=2,c=3,d=4;
    one ob;
    one ob2(a);
    one ob3(a,b);
    one ob4(a,b,c);
    one ob5(a,b,c,d);
}

