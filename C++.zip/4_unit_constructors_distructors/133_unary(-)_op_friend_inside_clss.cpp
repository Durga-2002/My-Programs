#include<iostream>
using namespace std;
class ex
{
private:
    int a;
public:
    ex()
    {
        cout<<"enter number:";
        cin>>a;
    }
    friend void operator ++(ex &ob)//ob
    {
      ++ob.a;//cout
    }
    void display()
    {
        cout<<a<<endl;
    }
};
main()
{
    ex ob;
    ob.display();
    ++ob;
    ob.display();
}
