#include<iostream>
using namespace std;
class  test
{
    int a;
public:
    test(int x)
    {
        a=x;
    }
    void display()
    {
        cout<<a<<endl;
    }
};
main()
{
    test ob[3]={1,2,3};
    ob[0].display();
    ob[1].display();
    ob[2].display();
}

