#include<iostream>
using namespace std;
class ex
{
    int a;
public:
    ex()
    {
        a=10;
    }
    void display() volatile
    {
        cout<<a<<endl;
        a=30;
        cout<<a<<endl;
        show();

    }
    void show() volatile
    {
        cout<<"hello";
    }
};
main()
{
    volatile ex ob;
    ob.display();
}

