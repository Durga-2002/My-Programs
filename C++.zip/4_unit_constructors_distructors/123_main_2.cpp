#include<iostream>
using namespace std;
class test
{
public:
    test()
    {
        cout<<"hello";
    }
}ob;
//test ob;
main()
{

}

