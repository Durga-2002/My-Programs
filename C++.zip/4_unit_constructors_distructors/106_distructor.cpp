#include<iostream>
using namespace std;
class example
{
public:
    example()
    {
        cout<<"hello";
    }
    ~example()
    {
        cout<<"end";
    }
};
main()
{
    example ob1,ob2,ob3;

}

