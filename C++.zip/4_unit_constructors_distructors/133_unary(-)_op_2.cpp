#include<iostream>
using namespace std;
class one
{
private:
    int a;
public:
    one()
    {
        cout<<"enter number:";
        cin>>a;
    }
    void operator -()
    {
        a=-a;//this->a=-a;
    }
    void display()
    {
        cout<<a<<endl;
    }
};
main()
{
    one ob;
    ob.display();
    -ob;
    ob.display();
}
