#include<iostream>
using namespace std;
class test
{
public:
    test()
    {
        cout<<"hello";
    }
}ob1;
test()
{
    cout<<"global.";
};
main()
{
test::ob1;
}

