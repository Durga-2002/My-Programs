#include<iostream>
using namespace std;
class one
{
private:
    int a;
public:
    void read()
    {
        cout<<"enter number:";
        cin>>a;
    }
    void display()
    {
        cout<<"a="<<a<<endl;
    }
   friend void operator -(one ob1);
};
void operator -(one ob1)
{
    cout<<-ob1.a;
}

main()
{
    one ob;
    ob.read();
    ob.display();
    -ob;
}

