#include<iostream>
using namespace std;
class A1
{
protected:
    int a;
};
class A2:public A1
{
protected:
    int b;
};
class A3:public A1
{
protected:
    int c;
};
class A4:public A2,A3
{
protected:
    int d;
public:
    void show()
    {
        a=10;
        b=20;
        c=30;
        d=40;
        cout<<a<<endl<<b<<endl<<c<<endl<<d;
    }
};
main()
{
    A4 b;
    b.show();
}
