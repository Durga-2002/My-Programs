#include<iostream>
using namespace std;
class I
{
    public:
      I()
      { cout <<"\n Zero argument constructor of base class I "; }
};
class II
{
     public:
       II()
       { cout<<"\n Zero argument constructor of base class II ";}
};
class III : public II,I
{
    public:
     III() : II(), I()
     { cout<<"\n Zero argument constructor of base class III "; }
};
main()
{
    cout<<"Name:V.Durga\nId:s170480\nSection:C"<<endl;
    III i;
}




