#include<iostream>
using namespace std;
class A
{
public:
    int x;
};
class B:public A
{
public:
    int y;
};
main()
{
    B b;
    b.y=90;
    b.x=85;
    cout<<"Name:V.Durga\nId:s170480\nSection:C"<<endl;
    cout<<"Member of A="<<b.x<<"\n"<<"Member of B="<<b.y;
}
