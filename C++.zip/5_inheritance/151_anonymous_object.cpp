#include<iostream>
using namespace std;
class A
{
    public:
        int a;
         A( )
         {
             a=10;
             }
};
class B : public A
{
    public:
        int b;
        B( )
        {
            b=20;
        }
        ~ B( )
        {  cout <<"\n a= "<<a <<" b = "<<b;}
};
main ( )
{
    B( );
}
class A {  public:    int a;    private:    int b;    public:    A( ){a=10,b=20;} }; void main( ){ A a;}
