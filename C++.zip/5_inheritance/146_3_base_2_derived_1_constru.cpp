#include<iostream>
using namespace std;
class I
{
     public :
         int x;
       I( )
       { cout <<"\nZero argument base class constructor "; }
       I( int k)
       { cout <<"\nOne argument base class constructor";   }
};
class II : public I
{
    int y;
    public:
     II (int j)
     {      cout <<"\nOne argument derived class constructor ";
            y=j;
     }
};
main()
{
  cout<<"Name:V.Durga\nId:s170480\nSection:C"<<endl;
  II i(2);
}


