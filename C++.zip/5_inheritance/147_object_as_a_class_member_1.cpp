#include<iostream>
using namespace std;
class A
{
    public:
    int a;
      A()
      {
        cout<<"\n constructor of class A";
        a=20;
      }
};
class B
{
    private:
        int b;
        A one;
    public:
        B()
        {
            cout<<"\nconstructor of class B";
            b=30;
        }
        void show()
        {
            cout<<"\nx="<<one.a<<"\ny="<<b;
        }
};
main()
{
    cout<<"Name:V.Durga\nId:s170480\nSection:C"<<endl;
    B two;
    two.show();
}
