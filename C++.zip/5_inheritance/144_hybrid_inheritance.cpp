#include<iostream>
using namespace std;
class player
{
protected:
    char name[20];
    int age;
};
class physique:public player
{
protected:
    float height;
};
class location
{
    protected:
    char city[20];
};
class game:public  physique,location
{
protected:
    char game[20];
public:
    void show()
    {
        cout<<"enter name and age:";
        cin>>name>>age;
        cout<<"enter height:";
        cin>>height;
        cout<<"enter city:";
        cin>>city;
        cout<<"enter game:";
        cin>>game;
        cout<<"\nname:"<<name<<"\nage:"<<age<<"\nheight:"<<height<<"\ncity:"<<city<<"\ngame:"<<game;
    }

};
main()
{
    cout<<"Name:V.Durga\nId:s170480\nSection:C"<<endl;
    game b;
    b.show();

}
