#include<iostream>
using namespace std;
class A
{
private:
    int x;
public:
    void read()
    {
        x=89;
        cout<<"Name:V.Durga\nId:s170480\nSection:C"<<endl;
        cout<<"x="<<x;
    }
};
class B:private A
{
public:
    int y;
    void show()
    {
        read();
        y=90;
        cout<<"\ny="<<y;
    }
};
main()
{
    B b;
    b.show();
}
