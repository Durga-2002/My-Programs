#include<iostream>
using namespace std;
class A
{
public:
    int a;
    void show()
    {
        a=10;
        cout<<"\nIn base class function a="<<a;
    }
};
class B:public A
{
public:
   void show()
    {
        cout<<"\nIn derived class function.";
    }
};
main()
{
    cout<<"Name:V.Durga\nId:s170480\nSection:C"<<endl;
    B b;
    b.show();
    A a;
   a.show();
   b.A::show();
}
