#include<iostream>
using namespace std;
class A
{
private:
    int a,b;
public:
    A()
    {
        a=10;
        b=20;
    }

};
class B:private A
{
public:
    int c;
    B()
    {
       c=30;
    }
};
main()
{
    cout<<"Name:V.Durga\nId:s170480\nSection:C"<<endl;
    B b;
    int *p;
    p=&b.c;
    cout<<"c="<<*p;*p--;
    cout<<"\nb="<<*p;*p--;
    cout<<"\na="<<*p;

}
