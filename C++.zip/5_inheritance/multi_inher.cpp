#include<iostream>
using namespace std;
class person
{
public:
    char name[20];
    person()
    {
        cout<<"enter the name:";
        cin>>name;
    }
    char* get_name()
    {
        return name;
    }
};
class student1:public person
{
  public:
      int id;
      student1()
      {
          cout<<"enter id number:";
          cin>>id;
      }
      int get_id()
      {
          return id;
      }
};
class student2:public student1
{
public:
    char address[20];
    student2()
    {
      cout<<"enter address:";
      cin>>address;
    }
    void print()
    {
        cout<<"name="<<get_name();
        cout<<"\nid="<<get_id();
        cout<<"\naddress="<<address;
    }
};
main()
{
    student2 ob;
    ob.print();
}

