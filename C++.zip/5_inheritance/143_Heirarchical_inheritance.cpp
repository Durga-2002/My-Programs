#include<iostream>
using namespace std;
class A
{
public:
    A()
    {
        cout<<" one";
    }
};
class B
{
 public:
    B()
    {
        cout<<"  two";
    }
};
class C
{
public:
    C()
    {
        cout<<"  =three";
    }
};
class three:public A,B
{
 public:
     three()
     {
     cout<<"  class three";
     }

};
class five:public B,C
{
 public:
     five()
     {
     cout<<" class five";
     }
};
class numbers:public three
{
    public:
    numbers()
    {
        cout<<"  =numbers";
    }
};
main()
{
    cout<<"Name:V.Durga\nId:s170480\nSection:C"<<endl;
    numbers b;
    endl(cout);
    five f;
    endl(cout);
}
