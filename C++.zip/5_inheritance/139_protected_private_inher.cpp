#include<iostream>
using namespace std;
class A
{
protected:
    int x;
};
class B:private A
{
private:
    int y;
public:
    B()
    {
      x=30;
      y=90;
    }
    void show()
    {
     cout<<"Name:V.Durga\nId:s170480\nSection:C"<<endl;
     cout<<"x="<<x<<endl<<"y="<<y;

    }

};
main()
{
    B b;
    b.show();
}
