#include<iostream>
using namespace std;
class A
{
public:
    int a;
};
class B
{
public:
    int b;
};
class AB:public A,B
{
public:
    A one;
    B two;
    AB()
    {
     one.a=10;
     two.b=20;
     cout<<one.a;
     cout<<"\n"<<two.b;

    }
    ~AB()
    {

    }
};
main()
{
    cout<<"Name:V.Durga\nId:s170480\nSection:C"<<endl;
    AB three;
}
