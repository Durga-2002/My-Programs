#include<iostream>
using namespace std;
class A1
{
protected:
    char name[20];
};
class A2: public A1
{
protected:
    float height;
};
class A3:public A2
{
protected:
    int age;
public:
    void show()
    {
      cout<<"Name:V.Durga\nId:s170480\nSection:C"<<endl;
      cout<<"enter name:";
      cin>>name;
      cout<<"enter height:";
      cin>>height;
      cout<<"enter age:";
      cin>>age;
      cout<<endl<<"\nname:"<<name<<"\nage:"<<age<<"\nheight:"<<height;
    }
};
main()
{
    A3 b;
    b.show();
}
