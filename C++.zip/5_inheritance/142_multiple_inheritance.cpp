#include<iostream>
using namespace std;
class A
{
protected:
    int a;
};
class B
{
protected:
    int b;
};
class C
{
protected:
    int c;
};
class D
{
protected:
    int d;
};
class E:public A,B,C,D
{
protected:
    int e;
public:
    void show()
    {
        cout<<"enter values:";
        cin>>a>>b>>c>>d>>e;
        cout <<"\n a="<<a <<"\n b="<<b <<"\n c="<<c <<"\n d="<<d <<"\n e="<<e;
    }

};
main()
{
    E b;
    b.show();
}
