#include<iostream>
using namespace std;
class A
{
  public:
      int x;
};
class B : private  A
{
 public:
     int y;
  B( )
  {
   x=20;
   y=40;
  }
  void show( )
  {
      cout<<"Name:V.Durga\nId:s170480\nSection:C";
      cout <<"\n x="<<x;
      cout <<"\n y="<<y;
  }
};
main( )
{
 B b;
 b.show( );
}

