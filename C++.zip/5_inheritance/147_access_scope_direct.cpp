#include<iostream>
using namespace std;
class A
{
public:
  char name[20];
};
class B:public A
{
private:
    int age;
    A one;
public:
    B()
    {
        cout<<"\nusing scope operator:";
        cout<<"\nname:";
        cin>>A::name;
        cout<<"name:"<<A::name;

        cout<<"\nusing object:";
        cout<<"\nname:";
        cin>>one.name;
        cout<<"name:"<<one.name;


        cout<<"\nusing direct member variable:";
        cout<<"\nname:";
        cin>>name;
        cout<<"age:";
        cin>>age;
        cout<<"name:"<<name;
        cout<<"\nage:"<<age;
    }
};
main()
{
    cout<<"Name:V.Durga\nId:s170480\nSection:C"<<endl;
    B two;
}
