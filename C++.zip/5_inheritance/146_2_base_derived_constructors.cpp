#include<iostream>
using namespace std;
class I
{
    public :
       I( )
       {   cout <<"\n In base class constructor ";   }
};
class II : public I
{
    public:
        II( )
        {     cout <<"\n In derived class constructor\n"; }
};
main( )
{
    cout<<"Name:V.Durga\nId:s170480\nSection:C"<<endl;
    II i;
}


