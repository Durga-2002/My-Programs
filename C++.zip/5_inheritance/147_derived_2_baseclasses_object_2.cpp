#include<iostream>
using namespace std;
class A
{
public:
    int a;
    A()
    {
        a=30;
    }
};
class B
{
public:
    int b;
    B()
    {
        b=20;
    }
};
class AB:public A,B
{
public:
    A one;
    B two;
    AB()
    {
     cout<<one.a;
     cout<<"\n"<<two.b;

    }
    ~AB()
    {

    }
};
main()
{
    AB three;
}

