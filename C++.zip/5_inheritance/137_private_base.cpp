#include<iostream>
using namespace std;
class A
{
private:
    int x;
public:
    A()
    {
        x=85;
    }
    void read()
    {
        cout<<"Name:V.Durga\nId:s170480\nSection:C"<<endl;
        cout<<"x="<<x;
    }

};
class B:public A
{
private:
    int y;
public:
   void show()
   {
       read();
       y=90;
       cout<<"\ny="<<y;
   }
};
main()
{
    B b;
    b.show();
}

