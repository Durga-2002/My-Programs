#include<iostream>
using namespace std;
class A
{
public:
    int a;
    class B
    {
    public:
        int b;
    };
};
class C:public A,A::B
{
public:
    int c;
    C(int i=10,int j=20,int k=30)
    {
     a=i;
     b=j;
     c=k;
    }
    void show()
    {
        cout<<"x="<<a<<"\ny="<<b<<"\nz="<<c;
    }
};
main()
{
    cout<<"Name:V.Durga\nId:s170480\nSection:C"<<endl;
    C three(5,6);
    three.show();
}

