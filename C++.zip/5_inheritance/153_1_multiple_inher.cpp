#include<iostream>
using namespace std;
class A
{
private:
    int a;
public:
    A()
    {
        cout<<"enter a value:";
        cin>>a;
    }

    ~A()
    {
     cout<<"\n"<<a;
    }

};
class B
{
private:
    int b;
public:
    B()
    {
        cout<<"enter b value:";
        cin>>b;
    }
    ~B()
    {
        cout<<"\n"<<b;
    }
};
class C: public A,B
{
private:
    int c;
public:

    C()
    {
        cout<<"enter c value:";
        cin>>c;
    }
    ~C()
    {
        cout<<"\n"<<c;
    }
};
main()
{
    C one;
}
