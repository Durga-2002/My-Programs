#include<iostream>
using namespace std;
class ABC
{
protected:
    char name[20];
    int age;
};
class abc:public ABC
{
public:
    float height,weight;
    void show()
    {
        cout<<"Name:V.Durga\nId:s170480\nSection:C"<<endl;
        cout<<"enter name and age:";
        cin>>name>>age;
        cout<<"enter height and weight:";
        cin>>height>>weight;
        cout<<endl<<"name:"<<name<<"\nage:"<<age<<"\nheight:"<<height<<"\nweight:"<<weight;

    }

};
main()
{
    abc b;
    b.show();
}
