#include<iostream>
using namespace std;
class A
{
public:
    A()
    {
        cout<<"\none.";
    }
};
class B:public A
{
public:
    B()
    {
        cout<<"\ntwo.";
    }
};
class C:public A
{
public:
    C()
    {
        B c;
        cout<<"\nthree.";
    }
};
main()
{
    C ob;
}
