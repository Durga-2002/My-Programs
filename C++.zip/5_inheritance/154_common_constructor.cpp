#include<iostream>
using namespace std;
class A
{
    protected:
        int x;
        int y;
};
class B:private A
{
     public:
         int z;
          B( )
          {
              x=1,y=2,z=3;
              cout <<"x= "<<x <<"\ny ="<<y <<"\nz="<<z;
          }
};
main()
{
    cout<<"Name:V.Durga\nId:s170480\nSection:C"<<endl;
    B b;
}



