#include<iostream>
using namespace std;
main()
{
    int a,b,res;
    cout<<"enter values:";
    cin>>a>>b;
    try
    {
        if(b==0)
            throw "divided by zero.";
        else
            res=a/b;
            cout<<res;
    }
    catch(const char s[10])
    {
        cout<<s;
    }
}
