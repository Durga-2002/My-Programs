#include<iostream>
using namespace std;
void check(int k) throw(char,int,double)
{
    cout<<"\nstart function.";
      if(k==1)  throw 'k';
      else if (k==2) throw k;
      else if (k==-2) throw 1.0;
      cout<<"\n end function.";
}
main()
{
    cout<<"\n main start.";
    try
    {
        //check(1);
        //check(2);
        check(-2);
        //check(10);
    }
    catch(int j)
    {
        cout<<"\ninteger exception.";
    }
    catch(double k)
    {
        cout<<"\ndouble exception.";
    }
    catch(char t)
    {
        cout<<"\nchar exception.";
    }
    cout<<"\n main end";
}
