#include<iostream>
using namespace std;
main()
{
     int x,y;
     cout <<"\n Enter values of x and y\n";
     cin>>x>>y;
     int j;
     j=x>y ? 0 :1;
     try
     {
         if(j==1)
            throw (j);
         else
            cout <<"Subtraction (x-y)= "<<x-y<<"\n";
     }
     catch(int j)
     {
         cout <<"Exception caught : j = "<<j <<"\n";
     }
}
