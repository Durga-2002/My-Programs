#include<iostream>
using namespace std;
void sub(int j,int k)
{
    try
    {
      if(j==0)
            throw j;
      else
        cout<<"\nsubtraction="<<j-k;
    }
    catch(int a)
    {
        cout<<"\ncaught null value.";
        throw;
    }
    cout<<"\nend of the function.";
}
main()
{

    cout<<"main start.";
    try
    {
    sub(3,4);
    sub(0,6);
    }
    catch(int j)
    {
        cout<<"\ncaught null value inside the main.\n";
    }
    cout<<"end of the main.";

}
