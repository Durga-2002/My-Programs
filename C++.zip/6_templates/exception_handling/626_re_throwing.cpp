#include<iostream>
using namespace std;
void myhandler()
{
    cout<<"start of function.";
    try
    {
        throw "hello\n";
    }
    catch(const char *str)
    {
        cout<<"\ncaught exception inside function.\n";
        cout<<str;
        throw;
    }
    cout<<"end of the function.";
}
main()
{
    cout<<"main start\n";
    try
    {
        myhandler();
    }
    catch(const char* str)
    {
        cout<<"\n caught exception inside main.\n";
        cout<<str;
    }
    cout<<"\n main end";
}
