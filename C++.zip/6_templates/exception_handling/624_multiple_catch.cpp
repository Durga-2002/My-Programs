#include<iostream>
using namespace std;
void  num(int k)
{
    try
    {
        if(k==0)
            throw (k);
        if(k<0)
            throw 'p';
        if(k>0)
            throw .0;
        cout<<"try block.";
    }
    catch (int j)
    {
        cout<<"\ncaught a null value.";
    }
    catch(char s)
    {
        cout<<"\ncaught a negative value.";
    }
    catch(double f)
    {
        cout<<"\ncaught a positive value.";
    }
    cout<<"\ncatch block.";
}
main( )
{
    cout <<"Demo of multiple catches\n";
    num(0);
    num(5);
    num(-1);
    //num('c');
}
