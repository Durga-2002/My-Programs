#include<iostream>
using namespace std;
void  num(int k)
{
    try
    {
        if(k==0)
            throw (k);
        if(k<0)
            throw 'p';
        if(k>0)
            throw .0;
        cout<<"try block.";
    }
    catch (...)
    {
        cout<<"\ncaught an exception.";
    }
    cout<<"\ncatch block.";
}
main( )
{
    cout <<"Demo of multiple catches\n";
    num(0);
    num(5);
    num(-1);
    //num('c');
}

