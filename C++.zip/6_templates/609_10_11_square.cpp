#include<iostream>
using namespace std;
template <class T>
class sqr
{
    public:
    sqr (T c)
    {
        cout <<"\n"<< " c = "<<c*c;
    }
};
main()
{ sqr <int> i(25);
  sqr <float> f(15.2);
}

