//Write a program to exchange values of two variables. Use template variables as function arguments.
#include<iostream>
using namespace std;
template  <class E>
void exchange(E &a, E &b)
{
   E t=a;
    a=b;
    b=t;
}
main()
{
   int x=5,y=8;
   cout <<"\n Before exchange "<<"x= "<<x <<" y= "<<y;
   exchange(x,y);
   cout <<"\n After exchange "<<"x= "<<x <<" y= "<<y;
}
