#include<iostream>
#include<stdlib.h>
using namespace std;
template <class T>
class node
{
    public:
    T data;
    node *next;
    node *head=NULL;
    void create()
    {
      char ch;
      while(ch!='n')
      {
          node *new_node,*temp;
          new_node=(node*)malloc(sizeof(node));
          cout<<"enter the data:";
          cin>>new_node->data;
          new_node->next=NULL;
          if(head==NULL)
          {
              head=new_node;
              temp=new_node;
          }
          else
          {
           temp->next=new_node;
           temp=new_node;
          }
          cout<<"do you want to enter the data:";
          cin>>ch;
      }
    }
    void display()
    {
        node *temp;
        cout<<"the linked list is:";
        temp=head;
        while(temp!=NULL)
        {
            cout<<""<<temp->data<<"-->";
            temp=temp->next;
        }
        cout<<"NULL";
    }

};
main()
{
    cout<<"Name:V.Durga\nId:s170480\nSection:C"<<endl;
    node <int> p;
    p.create();
    p.display();

}
