#include<iostream>
using namespace std;
template <class T>
class num
{
    T number;
public:
    num()
    {
        number=0;
    }
    void input()
    {
        cout<<"enter number:";
        cin>>number;
    }
    num operator + (num);
    void show()
    {
        cout<<number;
    }

};
template <class T>
num<T> num<T>::operator + (num <T> c)
{
    num<T> temp;
    temp.number=number+c.number;
    return temp;
}
main()
{
     num <int> n1,n2,n3;
     n1.input();
     n2.input();
     n3=n1+n2;
     cout <<"\n\t n3 = ";
     n3.show();
}
