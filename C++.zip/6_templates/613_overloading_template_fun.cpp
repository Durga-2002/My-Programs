//Write a program to overload a template function.
#include<iostream>
using namespace std;
template <class A>
void show(A c)
{
    cout <<"\n Template variable c = "<<c;
}
void show (int f)
{
    cout <<"\n Integer variable f = "<<f;
}
main()
{
    show('C');
    show(50);
    show(50.25);
}
