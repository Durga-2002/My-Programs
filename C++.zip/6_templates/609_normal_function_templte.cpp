#include<iostream>
using namespace std;
template <class T>
void show(T c)
{
    cout<<"c="<<c<<endl;
}
main()
{
     char c='A';
     int i=89;
     double d=65.678;
     show(c);
     show(i);
     show(d);
}
