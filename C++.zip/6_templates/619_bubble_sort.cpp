#include<iostream>
using namespace std;
template <class S>
void b_sort( S u[], int k)
{
    for(int x=0;x<k-1;x++)
    {
        for (int y=k-1;x<y;y--)
        {
          if (u[y]<u[y-1])  // checks successive numbers
            {
                S p;
                p=u[y];           //   assigns to temporary variable
                u[y]=u[y-1];      // exchange of elements
                u[y-1]=p;         // collects from temporary variable
            }
        }
    }
}
main()
{
    int i[5]={4,3,2,1,-4};
    float f[5]={5.3,5.1,5.5,4.5,3.2};
    b_sort(i,5);     // call to function
    b_sort(f,5);     // call to function
    int x=0,y=0;
    cout <<"\nInteger array elements in ascending order:";
    while(x<5)
    {
        cout <<i[x++] <<" ";
    } // display contents of integer array
   cout <<"\nFloat array elements in ascending order : ";
    while( y<5)
    {
        cout <<f[y++] <<" ";  // displays contents of float array
    }
}
