#include<iostream>
using namespace std;
template <class S>
class stack
{
    S num[5];
    int head;
      public:
          stack()
          {
              head=-1;
          }
         S push ( S d)
         {
             if (head==4)
                cout<<endl<<"Stack is Full";
             else
                {
                    head++;
                    num[head]=d;
                }
          }
          S pop()
          {
              if (head==-1)
                {
                    cout<<"\n Stack is empty";
                    return NULL;
                }
              else
                {
                    S d=num[head];
                    head--;
                    return d;
                }
            }
};
main()
{
     stack <int> s1;
     for (int j=10;j<=60;j+=10)
     {
        s1.push(j);
     }
     for (int j=0;j<=5;j++)
     {
       cout<<endl<<s1.pop();
     }
     stack <float> s2;
     for (int j=1;j<=6;j++)
     {
        s2.push(.1+j );
     }
    for ( int j=0;j<=5;j++)
    {
        cout<<endl<<s2.pop();
    }
}


