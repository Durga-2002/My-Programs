#include<iostream>
#include<stdlib.h>
#include<assert.h>
using namespace std;
template <class O>
void display (O d)
{
    cout<<(float) (rand( )%(d*d))<<"\n";

  // if (d==1) exit(1);
  assert(d!=1);
  display(--d);
}
main()
{
    int x=10;
    display(x);
}

