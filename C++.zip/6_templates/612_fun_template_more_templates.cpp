//Write a program to display the elements of integer and float array using template variables with member function
#include<iostream>
using namespace std;
template <class T1, class T2>
class data
{
    public :
    void show (T1 a, T2 b)
    {
        cout  <<"\na = "<<a <<" b = "<<b;
    }
};
main()
{
    int i[]={1,2,3,4,5,6,7,8};
    float f[]={3.1,5.8,2.5,6.8,1.2,9.2,4.7};
    data <int,float> h;
    for (int m=0;m<7;m++)
        h.show(i[m],f[m]);
}
