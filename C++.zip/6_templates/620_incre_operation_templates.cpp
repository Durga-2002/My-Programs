#include<iostream>
using namespace std;
/*#define max(a) a + ++a
main ( )
{
    int a=10, c;
    c=max(a);
    cout<<c;
}*/
template <class T>
T max(T k)
{
    ++k;
    return k;
}
main()
{
    int a=10, c;
    c=max(a);
    cout<<c;
}
