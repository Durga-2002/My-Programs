#include<iostream>
using namespace std;
class data
{
     public :
     data(char c)
     {
         cout <<"\n"<< " c = "<<c <<" Size in bytes :"<<sizeof(c);
     }
     data(int c)
     {
         cout <<"\n"<< " c = "<<c <<" Size in bytes :"<<sizeof(c);
     }
     data(double c)
     {
         cout <<"\n"<< " c = "<<c <<" Size in bytes :"<<sizeof(c);
     }
};
main()
{
    data h('A');   // passes character type data
    data i(100);    // passes integer type data
    data j(68.2);   // passes double type data   return 0;
}
