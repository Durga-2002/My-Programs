//Write a program to define a constructor with multiple template variables.
#include<iostream>
using namespace std;
template <class T1,class T2>
class data
{
public:
    data(T1 a,T2 b)
    {
        cout<<"\na="<<a<<"b="<<b;

    }
};
main()
{
    data <int,float> i(2,2.2);
    data <int,char> h(15,'C');
    data <float,int> j(3.12,50);
}
