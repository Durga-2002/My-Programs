#include<iostream>
using namespace std;
template <class T>
class data
{
 public:
     data(T c)
     {
         cout<<"c="<<c<<"  size="<<sizeof(c)<<endl;
     }
};
main()
{
    data <char> h('A');
    data <int> i(100);
    data <double> j(12.34);
}
