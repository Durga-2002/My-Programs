//Write a program to define function template with multiple arguments.
#include<iostream>
using namespace std;
template <class A, class B, class C>
void show(A c,B i,C f)
{
    cout <<"\n c = "<<c <<" i = "<<i <<" f = "<<f;
}
main()
{
    show('A',8,50.25);
    show(7,'B',70.89);
}
