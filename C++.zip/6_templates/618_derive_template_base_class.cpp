#include<iostream>
using namespace std;
template <class T>
class one
{
    public:
        T x,y;
};
template <class S>
class two:public one <S>
{
    S z;
    public :
      two(S a, S b, S c)
      {
          x=a;
          y=b;
          z=c;
      }
      S show()
      {
          cout <<"\n x="<<x <<" y="<< y<<" z="<<z;
      }
};
main()
{
    two <int> i(2,3,4);
    i.show();
    two <float> f(1.1,2.2,3.3);
    f.show();
}

