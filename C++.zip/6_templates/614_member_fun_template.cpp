//Write a program to define definition of member function template outside the class and invoke the function.
#include<iostream>
using namespace std;
template <class T>
class data
{
    public :
        data (T c);
};
template <class T>
data<T>::data (T c)
{
    cout <<"\n"<< " c = "<<c;
}
main()
{
    data <char> h('A');
    data <int> i(100);
    data <float> j(3.12);
}
