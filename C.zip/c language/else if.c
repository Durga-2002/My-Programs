#include<stdio.h>
float main()
{
  float n;
  printf("enter value\n");
  scanf("%f",&n);
  if(marks>=9)
    printf("a grade\n");
  else if(marks>=8&&marks<9)
    printf("b grade\n");
  else if(marks>=7&&marks<8)
    printf("c grade\n");
  else
    printf("failed\n");
}






}
