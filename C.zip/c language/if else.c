#include<stdio.h>
main()
{ int a;
  printf("enter the value of a:");
  scanf("%d",&a);
if(a%2==0)
  printf("a is an even number",a);
else
  printf("a is an odd number",a);
  return 0;
}



