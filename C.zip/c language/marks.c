#include<stdio.h>
#include<math.h>
int main()
{
float marks;
printf("enter the value of marks :");
scanf("%f",&marks);
if(marks >=9)
 {printf("A grade\n");}
else if(marks>=8 && marks<9)
 {printf("B grade\n");}
else if(marks>=7 && marks<8)
 {printf("C grade\n");}
else
 {printf("failed");}
return 0;
}
