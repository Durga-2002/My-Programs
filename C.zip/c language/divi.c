#include<stdio.h>
int main()
{
int a,b,c;
printf("enter two numbers:");
scanf("%d%d",&a,&b);
c=a/b;
printf("dinvition of two numbers=%d",c);
return 0;
}
