#include<stdio.h>
main()
{
     int a;
     for(a=0;a<=22;a++)
       {
        a=+1;
       printf("%d",a);
       }

}
