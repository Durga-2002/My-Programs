#include<stdio.h>
main()
{ int n,i,t1,t2,t3;
    printf("n value:");
    scanf("%d",&n);
    t1=0;
    t2=1;
    printf("%d\n%d\n",t1,t2);
    for(i=2;i<=n;i++)
    {
      t3=t1+t2;
      printf("%d\n",t3);
      t1=t2;
      t2=t3;
    }
}
