#include<stdio.h>
main()
{
    int a,b,c,d;
   a=9;
   b=a++;
   c=6;
   d=++c;
   printf("%d\n%d\n%d\n%d\n",a,b,c,d);
}
