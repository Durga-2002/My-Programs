#include<stdio.h>
#include<conio.h>
int main()
{
int a,b;
int c;
printf("enter first number to add\n");
scanf("%d",&a);
printf("enter second number to add\n");
scanf("%d",&b);
c=a+b;
printf("sum of the numbers %d\n",c);
return 0;
}


