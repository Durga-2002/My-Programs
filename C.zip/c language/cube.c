#include<stdio.h>
int main()
{
int a,b;
printf("enter the number:");
scanf("%d",&a);
b=a*a*a;
printf("cube of the number=%d",b);
return 0;
}

