#include <stdio.h>
#include <conio.h>
int main()
{
    int v;
    printf("even and numbers between 1 to 100\n");
    printf("odd numbers between 1 to 100\n");
       for (v=1;v<=100;v++)
          {if(v%2==0)
              printf("%d\n",v);
              }
       for (v=1;v<=100;v++)
          {if(v%2==1)
            printf("%d\n",v);
            }
}





