#include<stdio.h>
int main()
{
int a,b,c;
printf("enter two numbers;");
scanf("%d%d",&a,&b);
if(a>b)
 c=a;
else
 c=b;
printf("largest number c=%d",c);
return 0;
}
