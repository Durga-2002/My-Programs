#include<stdio.h>
 main()
{
int a,b,c,d,e,f;
printf("enter two value :");
scanf("%d %d",&a,&b);
c=a+b;
printf("the sum is %d\n",c);
d=a-b;
printf("the difference is %d\n",d);
e=a*b;
printf("the product is %d\n",e);
f=a/b;
printf("the division is %d\n",f);
}








