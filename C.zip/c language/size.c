#include<stdio.h>
main()
{ int i,b;
   b=sizeof(i);
   printf("size of %d",b);
}
