#include<stdio.h>
#include<conio.h>
int main()
{
int sum,i,n;
scanf("%d",&n);
sum=0;
for(i=1;i<=n;i++)
   {sum=sum+i;
    }
 printf("%d",sum);
 }






