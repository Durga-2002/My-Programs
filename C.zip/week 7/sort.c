#include<stdio.h>
#include<string.h>
main()
{
  char str[]="simply easy learning";
  char temp;
  int i,j,n;
    n=strlen(str);
    printf("enter the string:%s",str);
    for(i=0;i<n;i++)
    {
     for(j=i+1;j<n;j++)
     {
      if(str[i]>str[j])
      {
       temp=str[j];
       str[j]=str[i];
       str[i]=temp;
      }
    }
   }
   printf("\nstring after sorting:%s",str);
}



