#include<stdio.h>
#include<string.h>
main()
{ int i=0,j;
  char str[10];
  printf("enter the string:");
  scanf("%s",str);
  j=strlen(str)-1;
  while(i<=strlen(str)/2)
  {
  if(str[i]==str[j])
  {
  i++;
  j--;
  }
  else break;
  }
  if(i>=j)
   printf("palindrom");
  else
   printf("not a palindrom");
}
