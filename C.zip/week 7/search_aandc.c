#include<stdio.h>
main()
{  char a[100][50];
    int count=0,i,n;
     printf("enter the number of strings:");
     scanf("%d",&n);
     for(i=0;i<n;i++)
     {
      printf("enter a string:");
      scanf("%s",a[i]);
     }
     printf("enter strings strating with c and a:");
     for(i=0;i<n;i++)
     {
       if(a[i][0]=='a'||a[i][0]=='c')
       {
        puts(a[i]);
        count++;
       }
    }
    if(count==0)
    {
     printf("strings are not matched");
    }
}
