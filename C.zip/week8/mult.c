#include <stdio.h>
int mul(int,int);
int main()
{
    int a,b,result;
    printf("Enter two integers:\n");
    scanf("%d %d",&a,&b);
    result=mul(a,b);
    printf("multiplication of two numbers:=%d",result);
}
int mul(int a,int b)
{
    int result=0,i;
    for(i=0;i<b;i++)
    {
        result=result+a;
    }
  return result;
}

