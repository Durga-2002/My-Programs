#include<stdio.h>
int stringcmp(char s1[100],char s2[100]);
int main()
{ char str1[100],str2[100];
printf("enter the string 1:");
scanf("%s",str1);
printf("enter the string 2:");
scanf("%s",str2);
 if(stringcmp(str1,str2)==0)
  {
  printf("strings are equal");
  }
 else
  {
  printf("strings are not equal");
  printf("\n");
  }
}
 int stringcmp(char s1[100],char s2[100])
 {
   int i=0;
   for(i=0;s1[i]!='\0';i++)
   {
    if(s1[i]!=s2[i])
    return 1;
   }
    return 0;
}
