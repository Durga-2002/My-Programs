#include<stdio.h>
void stringlwr(char s[100]);
void stringupr(char s[100]);
int main()
{
  char str[100];
  printf("enter any string:");
  scanf("%s",str);
  stringlwr(str);
  printf("string after stringlwr:%s\n",str);
  stringupr(str);
  printf("string after stringupr:%s\n",str);
}
void stringlwr(char s[100])
{
  int i=0;
  while(s[i]!='\0')
  {
   if(s[i]>='A'&&s[i]<='Z')
   {
    s[i]=s[i]+32;
   }
   ++i;
  }
}
void stringupr(char s[100])
{
 int i=0;
  while(s[i]!='\0')
  {
   if(s[i]>='a'&&s[i]<='z')
   {
    s[i]=s[i]-32;
   }
   ++i;
  }
}
