#include<stdio.h>
#include<math.h>
#include<stdlib.h>
main()
{
  int a,b;
    printf("enter two numbers:");
    scanf("%d%d",&a,&b);
    printf("quotient is:%d",divide(a,b));
}
 int divide(int x,int y)
 {
  if(y==0)
  {
  printf("error!");
  exit(1);
  }
  int sign=1;
  if(x*y<0)
  sign=-1;
  x=abs(x),y=abs(y);
  int quotient=0;
  while(x>=y)
  {
  x=x-y;
  quotient++;
  }
  printf("remainder is:%d\n",x);
  return sign*quotient;
 }
