#include<stdio.h>
void stringcpy(char s1[],char s2[]);
int main()
{
  char str1[100],str2[100];
  printf("enter the string1:");
  scanf("%s",str1);
  stringcpy(str2,str1);
  printf("string1:%s\nstring2:%s\n",str1,str2);
  return 0;
}
void stringcpy(char s2[100],char s1[100])
{
  int i=0;
  while(s1[i]!='\0')
  {
   s2[i]=s1[i];
   i++;
  }
  s2[i]='\0';
}
