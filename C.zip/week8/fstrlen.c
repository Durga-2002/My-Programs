#include<stdio.h>
int stringlength(char s[20]);
main()
{
 char str[100];
 int length;
 printf("enter the string:");
 scanf("%s",str);
 length=stringlength(str);
 printf("string length is:%d\n",length);
 return 0;
}
 int stringlength(char name[20])
 {
  int i=0,count=0;
  while(name[i]!='\0')
  {
   count+=1;
   i++;
  }
return count;
}
