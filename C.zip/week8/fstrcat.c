#include<stdio.h>
void stringcat(char s1[],char s2[]);
#define MAX_SIZE 50
main()
{
 char str1[100],str2[100];
 printf("enter string 1:");
 scanf("%s",str1);
 getchar();
 printf("enter string 2:");
 scanf("%s",str2);
 getchar();
 stringcat(str1,str2);
 printf("\nafter concatenate strings are:\n");
 printf("string 1:%s\nstring 2:%s",str1,str2);
 printf("\n");
}
void stringcat(char s1[50],char s2[50])
{
 int len,i,s1len;
 len=strlen(s1)+strlen(s2);
 if(len>MAX_SIZE)
 {
  printf("\nconcatenation is not possible!!!");
  return;
 }
  s1len=strlen(s1);
  for(i=0;i<strlen(s2);i++)
  {
   s1[s1len+i]=s2[i];
  }
  s1[s1len+i]='\0';
}
