#include<stdio.h>
main()
{ char name[20],ch;
   int i=0;
    printf("enter the string:");
    ch=getchar();
    while(ch!='$')
    {
     name[i]=ch;
     i++;
     ch=getchar();
     name[i]='\0';
    }
     printf("strin");
     printf("%s",name);
}
