#include<stdio.h>
#include<conio.h>
#include<string.h>
main()
{ char a[20];
   int n;
    printf("enter the string:");
    scanf("%s",a);
    n=strlen(a);
    printf("length of the string is:%d",n);
}
