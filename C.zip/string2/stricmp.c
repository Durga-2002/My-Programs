#include<stdio.h>
#include<string.h>
main()
{
 char a[20],b[20];
 int c;
   printf("enter first string:");
   scanf("%s",a);
   printf("entere second string:");
   scanf("%s",b);
   c=strcmp(b,a);
   printf("after copying string:%d",c);
}
