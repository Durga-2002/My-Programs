#include<stdio.h>
#include<string.h>
main()
{ char a[100];
     printf("enter the stirng:");
     gets(a);
     printf("your name is:");
     puts(a);



}
