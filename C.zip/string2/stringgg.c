#include<stdio.h>
main()
{
 char a[20];
  printf("enter a string gets() :");

  gets(a);
  printf("enter data is:will be with puts() :");

  puts(a);
   getch();
}
