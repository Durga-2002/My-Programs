#include<stdio.h>
#include<string.h>
main()
{ char a[20];
    printf("enter the string:");
    gets(a);
    strrev(a);
    printf("the reverse string is:%s",a);







}
