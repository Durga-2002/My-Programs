#include<stdio.h>
#include<string.h>
main()
{
 char ch;
  printf("enter charecz:");
  ch=getchar();
  putchar(ch);
}
