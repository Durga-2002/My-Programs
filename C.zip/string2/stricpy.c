#include<stdio.h>
#include<string.h>
main()
{
 char a[20],b[20];
   printf("enter first string:");
   scanf("%s",a);
   printf("entere second string:");
   scanf("%s",b);
   strcpy(b,a);
   printf("after copying string:%s",b);
}
