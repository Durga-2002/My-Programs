#include<stdio.h>
#include<string.h>
void main()
{ char name[30][20];
  int n,i;
    printf("enter the number of names:");
    scanf("%d",&n);
    printf("enter the name:");
    scanf("%s",name);
    for(i=0;i<n;i++)
    {
    printf("%s\n",name);
    }
     puts(i);
}
