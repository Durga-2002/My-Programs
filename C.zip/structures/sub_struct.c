#include<stdio.h>
struct student
{
  char name[50];
  int roll;
  struct dateofbirth
  {
   int dd;
   int mm;
   int yy;
  }dob;
}std;
int main()
{
   printf("\nenter name:");
 scanf("%s",&std.name);
 printf("\nenter roll number:");
 scanf("%d",&std.roll);
 printf("enter dob[dd mm yy]format:");
 scanf("%d%d%d",&std.dob.dd,&std.dob.mm,&std.dob.yy);
 printf("\nname:%s\nroll:%d\ndateofbirth:%d/%d/%d\n",std.name,std.roll,std.dob.dd,std.dob.mm,std.dob.yy);
 return 0;


}
