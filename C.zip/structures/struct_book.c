#include<stdio.h>
#include<string.h>
struct book
{
  char title[50];
  char authorname[20];
  int page;
  float price;
};
int main()
{
 struct book b1;
 strcpy(b1.title,"the complete reference c");
 strcpy(b1.authorname,"robert");
 b1.page=230;
 b1.price=500.0;

 printf("book name is %s",b1.title);
 printf("\nauthor of the book is %s",b1.authorname);
 printf("\nnumber of pages %d",b1.page);
 printf("\nbook price is %f",b1.price);
 return 0;
}
