#include<stdio.h>
struct addition
{
  int a,b;
  int c;
}sum;
int add(int a,int b);
int main()
{
 printf("enter a value:");
 scanf("%d",&sum.a);
 printf("enter b value:");
 scanf("%d",&sum.b);
 sum.c=add(sum.a,sum.b);
 printf("\n the sum of two values:");
 printf("%d",sum.c);
 return 0;
}
int add(int x,int y)
{
 int sum1;
  sum1=x+y;
  return  sum1;
}
