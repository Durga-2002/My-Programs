#include<stdio.h>
#include<string.h>
struct student
{
  char sname[50];
  int sid;
  float sage;
};
int main()
{
  struct student s[100]={{"rama",200,300},{"charan",299,677}};
  int i;
  for(i=0;i<2;i++)
  {
   printf("\n %d student details\n",i+1);
   printf("\nstudent name is %s",s[i].sname);
   printf("\nstudent id %d",s[i].sid);
   printf("\nstudent marks %f\n",s[i].sage);
  }
  return 0;




}
