#include<stdio.h>
struct student
{
 char sname[20];//*sname//
 int sid;
 int sage;
};
int main()
{ struct student s;
  strcpy(s.sname,"rama");//s.sname="rama";//
  s.sid=170480;
  s.sage=30;
  printf("student name is %s",s.sname);
  printf("\nstudent id is %d",s.sid);
  printf("\nstudent age is %d",s.sage);
  return 0;
}
