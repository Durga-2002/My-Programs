#include<stdio.h>
#include<string.h>
struct student
{
  char name[50];
  int roll;
  float marks;
}s;
int main()
{
 printf("enter information:");
 printf("\nenter name:");
 scanf("%s",s.name);
 printf("\nenter roll number:");
 scanf("%d",&s.roll);
 printf("\nenter marks:");
 scanf("%f",&s.marks);
 printf("\ncopying information:");
 printf("\nname:");
 puts(s.name);
 printf("\nroll number:%d",s.roll);
 printf("\nmarks:%f",s.marks);
 return 0;
}
