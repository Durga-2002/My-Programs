#include<stdio.h>
struct person
{
  int age;
  float weight;
};
int main()
{
  struct person *p,a;
  p=&a;
  printf("enter age:");
  scanf("%d",&p->age);
  printf("enter weight:");
  scanf("%f",&p->weight);
  printf("\nperson details:");
  printf("age:%d\n",(*p).age);//p->age//
  printf("weight:%f\n",(*p).weight);
  return 0;



}
