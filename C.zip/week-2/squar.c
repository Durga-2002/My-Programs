#include<stdio.h>
int main()
{
 int a,b;
 float c;
 printf("enter an integer number:");
 scanf("%d",&a);
 c=sqrt(a);
 b=c;
 if(c==b)
     printf("%d is a perfect square.",a);
else
     printf("%d is not a perfect square.",a);
    return 0;
}


