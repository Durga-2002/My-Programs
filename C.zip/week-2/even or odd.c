#include <stdio.h>
#include <conio.h>
main()
{
int a;
printf("enter the number:");
scanf("%d",&a);
if(a%2==0)
printf("a is an even number");
else
printf("a is an odd number");
}
