#include<stdio.h>
int main()
{
    float a;
    int b;
    char ch;

    printf("\nEnter the value of float:\n");
    scanf("%f", &a);

    printf("\nEnter the value of int:\n");
    scanf("%b", &b);

    printf("\nEnter the value of char:\n");
    scanf("%c", &ch);

    printf("\nvalue of float : %f", a);
    printf("\nvalue of int : %d", b);
    printf("\nvalue of char : %c", ch);
    printf("\nvalue of float(rounded) : %.3f", a);

    return 0;
}




