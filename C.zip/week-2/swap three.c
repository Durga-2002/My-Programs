#include<stdio.h>
main()
{
 int x,y,t;
 printf("enter two integers\n");
 scanf("%d%d",&x,&y);
 printf("before swapping\n first integer=%d\nsecond integer=%d\n",x,y);
 t=x;
 x=y;
 y=t;
 printf("after swapping\n first integer=%d\nsecond integer=%d\n",x,y);
 return 0;
}



