#include<stdio.h>
#include<conio.h>
void main()
{
  int a,b;
  int op;
  printf("1.addition\n2.subtraction\n3.multiplication\n4.division\n");
  printf("enter the values of a & b: ");
  scanf("%d %d",&a,&b);
  printf("enter your choice: ");
  scanf("%d",&op);
  switch(op)
  {
  case 1 :
     printf("addition of %d and %d is :%d",a,b,a+b);
     break;
  case 2 :
     printf("subtraction of %d and %d is:%d",a,b,a-b);
     break;
  case 3 :
     printf("multiplication of %a and %d is:%d",a,b,a*b);
     break;
  case 4 :
     printf("division of %d and %d is:%d",a,b,a/b);
     break;
  case 5 :
     printf("power of %d and %d is:%d",a,b,a^b);
     break;
  case 6 :
     printf("\nmodulus of %d and %d is:%d\n",a,b,a%b);
     break;
  }
     getch();
}



























