#include<stdio.h>
main()
{
 int a;
 printf("enter value of a:\n",a);
 scanf("%d",&a);
 if(a>0)
  printf("a is positive",a);
else if(a<0)
  printf("a is negative",a);
else if(a==0)
  printf("a is zero",a);
return 0;
}





