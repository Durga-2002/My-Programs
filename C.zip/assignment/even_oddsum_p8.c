#include<stdio.h>
main()
{    int a[10],i,n,sum=0,odd_sum=0;
     printf("Name:V.Durga\nID:s170480\n");
     printf("enter size of the array:");
     scanf("%d",&n);
     printf("enter elements into array:");
     for(i=0;i<n;i++)
     {
     scanf("%d",&a[i]);
     }
     for(i=0;i<n;i++)
     {
      if(a[i]%2==0)
        sum+=a[i];
      else
        odd_sum+=a[i];
     }
     printf("sum of the even integers:%d",sum);
     printf("\nsum of the odd integers:%d",odd_sum);
}
