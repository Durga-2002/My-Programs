#include<stdio.h>
main()
{  int A,B;
     printf("Name:V.Durga\nID:s170480\n");
     printf("enter the percentage of the student in exam a and b: ");
     scanf("%d%d",&A,&B);
     if(A>=55&&B>=45)
         printf("\nyour passed in both examinations A and B.");
       else if(A<=45&&A>=55&&B>=55)
         printf("\nyour passed in both exams A and B");
       else if(A>=65&&B<45)
         printf("\nyour passed in A exam and also your promoted to exam B.");
       else
         printf("\nyour failed.");









}
