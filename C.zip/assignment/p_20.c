#include<stdio.h>
main()
{  int a[10],n,sum=0,i;
     printf("Name:V.Durga\nID:s170480\n");
     printf("enter n value:");
     scanf("%d",&n);
     for(i=0;i<n;i++)
     {
      printf("enter a[%d]:",i);
      scanf("%d",&a[i]);
     }
     for(i=0;i<n;i++)
     {
      sum=a[i];
      a[i+1]=sum+a[i+1];
      printf("%d\n",a[i]);

     }



}
