#include<stdio.h>
main()
{
    int a[10],i,max,min,n;
     printf("Name:V.Durga\nID:s170480\n");
     printf("enter the range of array:");
     scanf("%d",&n);
     printf("enter elements into the array:");
     for(i=0;i<n;i++)
     {
      scanf("%d",&a[i]);
     }
     max=a[0];
     min=a[0];
     {
      for(i=0;i<n;i++)
      {
       if(a[i]>=max)
         max=a[i];
        if(a[i]<=min)
         min=a[i];
      }
    }
     printf("range is:%d",max-min);
}
