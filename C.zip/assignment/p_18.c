#include<stdio.h>
main()
{
   int a[100],i,n,c,m,max,j;
      printf("Name:V.Durga\nID:s170480\n");
      printf("enter the size:");
      scanf("%d",&n);
      printf("enter the elements:");
      for(i=0;i<n;i++)
      {
      scanf("%d",&a[i]);
      }
      m=2;
      for(i=0;i<n;i++)
      {
       c=1;
       for(j=i+1;j<n;j++)
       {
       if(a[i]==a[j])
       c++;
       if(c>=m)
       max=a[i];

       }

      }
    printf("the maximum times repeated elements:%d",max);



}
