#include<stdio.h>
main()
{  int a,b,c;
    printf("Name:V.Durga\nID:s170480\n");
    printf("enter three sides of the triangle:");
    scanf("%d%d%d",&a,&b,&c);
    if(a*a+b*b==c*c||b*b+c*c==a*a||c*c+a*a==b*b)
     {
      printf("right angle triangle.");

     }
    else if(a==b&&b==c&&c==a)
    {
        printf("equilateral triangle.");
    }
    else if(a==b&&b!=c&&a!=c||b==c&&c!=a&&b!=a||c==a&&c!=b&&a!=b)
    {
        printf("isosceles triangle.");
    }
    else
    {
        printf("scalene triangle.");
    }
}
