#include <stdio.h>
main()
{
   int n,sum,i;
   printf("Name:V.Durga\nID:s170480\n");
   printf("enter value\n");
   scanf("%d",&n);
   sum=0;
   while(n!=0)
   {  i=n%10;
      sum=sum+i;
      n=n/10;
   }
    printf("sum of digits is %d\n",sum);
}



