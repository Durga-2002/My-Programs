#include<stdio.h>
main()
{  int a;
     printf("Name:V.Durga\nID:s170480\n");
     printf("enter the year:");
     scanf("%d",&a);
     if(a%4==0)
      {
       printf("this is a leap year");
      }
    else
    {
    printf("this is not a leap year");
    }
}
