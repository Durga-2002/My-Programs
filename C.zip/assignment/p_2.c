#include<stdio.h>
int main()
{
    int year=1900;
    int n,leap,normaldays,totaldays,day;
    printf("Name:V.Durga\nID:s170480\n");
    printf("\nEnter present year:");
    scanf("%d",&n);
    n=(n-1)-year;
    leap=n/4;
    normaldays=n-leap;
    totaldays=(normaldays*365)+(leap*366)+1;
    day=totaldays%7;
    if(day==0)
    {
        printf("monday");
    }
    else if(day==1)
    {
        printf("tuesday");
    }
    else if(day==2)
    {
        printf("wednasday");
    }
    else if(day==3)
    {
        printf("thursday");
    }
    else if(day==4)
    {
        printf("friday");
    }
    else if(day==5)
    {
        printf("saterday");
    }
    else
    {
        printf("sunday");
    }
}


