#include<stdio.h>
main()
{ int x,n,i,j,fact=1;
    float sum=1;
   printf("Name:V.Durga\nID:s170480\n");
   printf("enter x value:");
   scanf("%d",&x);
   printf("enter n value:");
   scanf("%d",&n);
   for(i=1;i<n;i++)
   {
    for(j=1;j<=i;j++)
    {
     fact=fact*j;
     sum=sum+(pow(x,i)/fact);
    }
  }
   printf("sum is :%f",sum);
}















