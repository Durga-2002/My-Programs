#include<stdio.h>
main()
{
  int n,feets,meters,inches,centimeters;
   printf("Name:V.Durga\nID:s170480\n");
   printf("the distance between two cities in kilometers:");
   scanf("%d",&n);
   meters=n*1000;
   feets=n*3280;
   inches=n*39370.079;
   centimeters=n*100000;

   printf("\ndistance between two cities in meters:%d",meters);
   printf("\ndistance between two cities in feets:%d",feets);
   printf("\ndistance between two cities in inches:%d",inches);
   printf("\ndistance between two cities in centimeters:%d",centimeters);
}
