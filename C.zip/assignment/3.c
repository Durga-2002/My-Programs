#include<stdio.h>
main()
{
  int i,n;
   printf("enter the number:\n");
   scanf("%d",&n);
   printf("\nthese numbers are not divisible by 3:\n");
   for(i=0;i<=n;i++)
   {
     if(i%3!=0)
     {
     printf("%d\n",i);
     }
   }
   printf("\nthese are not divisible by 5:\n");
   for(i=0;i<=n;i++)
   {
    if(i%5!=0)
    {
    printf("%d\n",i);
    }
   }
}
