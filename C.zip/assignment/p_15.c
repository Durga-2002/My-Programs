#include<stdio.h>
main()
{
   int i,j,n;
   printf("Name:V.Durga\nID:s170480\n");
     printf("enter a number:");
     scanf("%d",&n);
     for(i=1;i<=n;i++)
     {
      for(j=1;j<=n;j++)
      {
      if((i==1||i==n)||(j==1||j==n))
      {
      printf(" 1 ");
      }
      else
      {
      printf(" 0 ");
      }
     }

     printf("\n");
     }
}
