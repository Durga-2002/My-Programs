#include<stdio.h>
main()
{  int n;
    printf("enter the number:");
    scanf("%d",&n);
    printf("Roman number:");
    if(n>=1000)
    {
    printf("M");
    }
    else if(n>=500)
    {
        printf("D");
    }
    else if(n>=100)
    {
        printf("C");
    }
    else if(n>=50)
    {
        printf("L");
    }
    else if(n>=10)
    {
        printf("X");
    }
    else if(n>=5)
    {
        printf("V");
    }
    else if(n>=1)
    {
        printf("I");
    }
    else if(n>=3)
    {
        printf("III");
    }





}
