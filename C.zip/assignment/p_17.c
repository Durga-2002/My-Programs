#include<stdio.h>
void strong(int c)
{  int  sum=0,b,num;
    num=c;
    while(c!=0)
    {
        b=c%10;
        sum=sum+fact(b);
        c=c/10;
    }
    if(sum==num)
        printf("\n%d",sum);
    sum=0;
}
 int fact(int a)
 {
     int facta=1,b;
     for(b=1;b<=a;b++)
        facta=b*facta;
     return facta;
 }
 void main()
 {
     int num,b;
     printf("enter range:");
     scanf("%d",&num);
     printf("the strong numbers are:");
     for(b=1;b<=num;b++)
     {
         strong(b);
     }
 }
