#include<stdio.h>
main()
{
int n;
printf("Name:V.Durga\nID:s170480\n");
printf("enter a decimal number:");
scanf("%d",&n);
printf("decimal to octal=%o\n",n);
printf("decimal to hexadecimal=%x\n",n);
}
