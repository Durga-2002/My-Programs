#include<stdio.h>
main()
{ int a[10],b[10],c[20],i,k;
   printf("Name:V.Durga\nID:s170480\n");
   printf("enter a elements in a:");
   for(i=0;i<10;i++)
   {
    scanf("%d",&a[i]);
    c[i]=a[i];
   }
   k=i;
   printf("enter a elements in b:");
   for(i=0;i<10;i++)
   {
   scanf("%d",&b[i]);
   c[k]=b[i];
   k++;
   }
   printf("c elements are:\n");
   for(i=0;i<k;i++)
   {
   printf("%d",c[i]);
   }
}
