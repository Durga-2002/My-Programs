#include<stdio.h>
main()
{ int a,b,c,op;
    printf("Name:V.Durga\nID:s170480\n");
    printf("enter three numbers:");
    scanf("%d%d%d",&a,&b,&c);
    printf("1.product\n2.smallest number\n3.biggest number\n4.middle number\n");
    printf("enter your choice:");
    scanf("%d",&op);
    switch(op)
    {
        case 1:
            printf("product is:%d",a*b*c);
            break;
        case 2:
            if(a<b&&a<c)
                printf("smallest number is:%d",a);
            else if(b<a&&b<c)
                printf("smallest number is:%d",b);
            else
                printf("smallest number is:%d",c);
            break;
        case 3:
            if(a>b&&a>c)
                printf("biggest number is:%d",a);
            else if(b>a&&b>c)
                printf("biggest number is:%d",b);
            else
                printf("biggest number is:%d",c);
                break;
        case 4:
            if(a>b&&a<c||a<b&&a>c)
                printf("middle number is:%d",a);
            else if(b>a&&b<c||b<a&&b>c)
                printf("middle number is :%d",b);
            else
                printf("middle number is:%d",c);
                break;
        default:
            printf("your choice is not valid.");
            break;
    }


}
