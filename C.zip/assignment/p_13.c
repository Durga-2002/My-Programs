#include<stdio.h>
int fact(int);
main()
{
  int i,n;
  float sum=0;
   printf("Name:V.Durga\nID:s170480\n");
   printf("enter n value:");
   scanf("%d",&n);
   for(i=1;i<=n;i++)
    {
    sum=sum+(float)i/fact(i);
    }
    printf("sum is :%f\n",sum);
}
int fact(int a)
{
  int i,fact=1;
  for(i=1;i<=a;i++)
  {
  fact=fact*i;
  }
  return (fact);
}
