#include<stdio.h>
main()
{  int days;
       printf("Name:V.Durga\nID:s170480\n");
       printf("enter number of days you did late:");
       scanf("%d",&days);
       if(days<=5)
         printf("\nyou should pay 50 paise as fine.");
       else if(days>=6&&days<=10)
         printf("\nyou should pay 1 rupee as fine.");
       else if(days>10&&days<30)
         printf("\nyou should pay 5 rupees as fine.");
       else
         printf("\nyour membership will be cancelled.");
}
