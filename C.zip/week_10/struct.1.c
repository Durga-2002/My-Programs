#include<stdio.h>
struct student
{
  int regid;
  char name[50];
  float CGPA;
  struct address
  {
   char village[40];
   char dist[30];
   long int  phno;
  }add;
};
int main()
{
  struct student s[10];
  int n,i;
  printf("enter no of student:");
  scanf("%d",&n);
  for(i=0;i<n;i++)
  {
   printf("\nenter regid:");
   scanf("%d",&s[i].regid);
   printf("\nenter name:");
   scanf("%s",s[i].name);
   printf("\nenter cgpa:");
   scanf("%f",&s[i].CGPA);
   printf("\nenter address-village\ndis\nphone number:\n");
   scanf("%s%s%ld",&s[i].add.village,&s[i].add.dist,&s[i].add.phno);
 }
  printf("\nstudent details are:\n");
  printf("Regid\tName\tCGPA\tAddress\n");
  for(i=0;i<n;i++)
  {
   printf("%d\n",s[i].regid);
   printf("%s\n",s[i].name);
   printf("%f\n",s[i].CGPA);
   printf("%s%s%ld",s[i].add.village,s[i].add.dist,s[i].add.phno);
  }
  int topper=s[0].CGPA,t_no;
  for(i=1;i<n;i++)
  {
   if(s[i].CGPA>topper)
    topper=s[i].CGPA;
    t_no=i;
  }

 printf("\ntopper student details:\n");
 printf("%d\n",s[t_no].regid);
 printf("%s\n",s[t_no].name);
 printf("%f\n",s[t_no].CGPA);
 printf("%s%s%ld",s[t_no].add.village,s[t_no].add.dist,s[t_no].add.phno);
}
