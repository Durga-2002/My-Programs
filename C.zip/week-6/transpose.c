#include<stdio.h>
int main()
{ int a[10][10],m,n,i,j,Ta[10][10];
      printf("enter size of the array: ");
      scanf("%d%d",&m,&n);
      printf("enter values into array: ");
      for(i=0;i<m;i++)
      {
        for(j=0;j<n;j++)
        {
         scanf("%d",&a[i][j]);
        }
      }
      for(i=0;i<m;i++)
       {
        for(j=0;j<n;j++)
        {
         Ta[i][j]=a[j][i];
        }
       }
       printf("the transpose of matrix\n");
       for(i=0;i<n;i++)
       {
        for(j=0;j<m;j++)
        {
         printf("%d",Ta[i][j]);
        }
        printf("\n");
       }
       return 0;
}
