#include<stdio.h>
#include<string.h>
void main()
{
int n,start,end,i=0;
char str1[10],str2[10];
printf("\n enter the string :");
gets(str1);
printf("\n enter the starting index and ending index value : ");
scanf("%d %d",&start,&end);
for(n=start;n<=end;n++)
{
str2[i]=str1[n];
i++;
}
str2[i]='\0';
printf("sub string is %s",str2);
getch();
}
