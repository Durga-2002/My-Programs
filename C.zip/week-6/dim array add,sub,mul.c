#include<stdio.h>
main()
{
    int  a[10][10],b[10][10],f[10][10],d[10][10], i,j,r,c;
     printf("enter the size of matrix");
     scanf("%d,%d",&r,&c);
     printf("enter the values into a matrix\n");
     for(i=0;i<r;i++)
     {
      for(j=0;j<c;j++)
      {
       scanf("%d",&a[i][j]);
      }
     }
     printf("enter the values into b matrix\n");
     for(i=0;i<r;i++)
     {
     for(j=0;j<c;j++)
      {
       scanf("%d",&b[i][j]);
      }
     }
     for(i=0;i<r;i++)
     {
      for(j=0;j<c;j++)
      {
       f[i][j]=a[i][j]+b[i][j];
       d[i][j]=a[i][j]-b[i][j];

      }
     }
     printf("the addition is:\n");
     for(i=0;i<r;i++)
      {
       for(j=0;j<c;j++)
       {
         printf("%d",f[i][j]);
       }
      printf("\n");
      }
      printf("the subtraction is:\n");
       for(i=0;i<r;i++)
        {
         for(j=0;j<c;j++)
          {
            printf("%d",d[i][j]);
          }
          printf("\n");
        }
}
