#include<stdio.h>
main()
{
    int n,i;
   unsigned long long factorial=1;
   printf("enter n value\n");
   scanf("%d",&n);
   if(n<0)
   {
     printf("error!factorial does not exist");
   }
   else
   {
     for(i=1;i<=n;i++)
     {
       factorial=factorial*i;
     }
      printf("factorial of %d=%llu",n,factorial);
   }
}








