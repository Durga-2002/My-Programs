#include<stdio.h>
main()
{ int num,i;
  printf("enter a positive integer\n");
  scanf("%d",&num);

  printf("factors of %d are:",num);
  for(i=1;i<=num;i++)
  {
    if(num%i==0)
    {
      printf("%d\n",i);
    }
  }
}
