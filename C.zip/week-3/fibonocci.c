#include<stdio.h>
main()
{ int n,first=0,second=1,c,next;
  printf("enter a number of terms:");
  scanf("%d",&n);

  printf("%d\n%d\n",first,second);
  for(c=3;)
}
