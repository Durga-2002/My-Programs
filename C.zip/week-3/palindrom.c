#include<stdio.h>
main()
{ int n,r,temp,sum=0;
  printf("enter number\n");
  scanf("%d",&n);
  temp=n;
  while(n>0)
  {
   r=n%10;
   sum=sum*10+r;
   n=n/10;
  }
  if(temp==sum)
    printf("given number is palindrome");
  else
    printf("given number is not a palindrome");
}
