#include <stdio.h>
#include<stdlib.h>
int main(int argc,char *argv[])
{
   int sum,n1,n2;
    printf("Total arguments=%d",argc);
    printf("first argument=%s",argv[0]);
   printf("second argument=%s",argv[1]);
     printf("\n enter the n1 value:");
      scanf("%d",&n1);
    printf("\n enter the n2 value:");
      scanf("%d",&n2);
	sum=n1+n2;
	printf("Sum of two numbers=%d",sum);
    return 0;
}
