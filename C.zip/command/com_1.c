#include<stdio.h>
int main(int argc,char* argv[])
{
  printf("total arguments=%d",argc);
  printf("first arguments=%s",argv[0]);
  printf("second arguments=%s",argv[1]);
  printf("third arguments=%s",argv[2]);
 return 0;
}