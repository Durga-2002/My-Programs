int power(int base,int exp)
{
 if(exp==0)
    return 1;
 else
    return base*power(base,exp-1);
}
void main()
{
    int b,e,result;
    printf("enter base and exponent:\n");
    scanf("%d%d",&b,&e);
    result=power(b,e);
    printf("result:%d",result);
}
