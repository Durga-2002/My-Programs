void display(int i,int n)
{
 if(i==n+1)
 return;
 else
 {
  printf("%d\n",i);
  display(i+1,n);
 }
}
 void print(int n)
 {
  if(n==0)
  return;
  else
  {
  printf("%d\n",n);
  print(n-1);
  }
}
void main()
{
 printf("\nNumbers from 1 to N:\n");
 display(1,10);
 printf("\nNumbers from N to 1:\n");
 print(10);
}











