#include<stdio.h>
main()
{
  int count=0,i=0;
  char str[50];
  char *ptr;
  ptr=str;
  printf("enter the string:");
  scanf("%s",str);
  while(*(str+i)!='\0')
  {
   count++;
   i++;
  }
printf("%d",count);






}
