#include <stdio.h>
int main( void )
{
  int  a=12 ;
  int *pa ;
  pa  = &a ;
  *pa = 77 ;
  printf("a=%d   *pa=%d\n", a, *pa );
  return 0;
}
