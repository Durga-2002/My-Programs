#include<stdio.h>
main()
{ int *a;
  a=(int*)malloc(100/*sizeof(int)*/);
  printf("enter the value:");
  scanf("%d",&a);
  printf("%d",*a);




}
