#include<stdio.h>
int main()
{
  int first,second,*p,*q











}
