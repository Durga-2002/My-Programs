#include<stdio.h>
main()
{
  int a=36;
  int* ptr;
  ptr=&a;
  printf("%u\n%u",*&ptr,&*ptr);
}
