#include<stdio.h>
#include<stdlib.h>
int main()
{ int *a;
  int n,i;
  printf("enter n value:");
  scanf("%d",&n);
  a=(int*)malloc(sizeof(int));
  for(i=0;i<n;i++)
  {
   printf("enter the elements:");
   scanf("%d",a+i);
  }
  printf("\nelements are:");
  for(i=0;i<n;i++)
  {
  printf("%d",*(a+i));
  }
return 0;
}
