#include<stdio.h>
main()
{ int *a[10],sum,i,n,avg;
   printf("enter the array values");
   scanf("%d",&n);
   for(i=0;i<n;i++)
   {
    printf("enter arr[%d] : ",i);
    scanf("%d",&*(a+i));
   }
   sum=0;

   for(i=0;i<n;i++)
   {

    sum=sum+(*(a+i));
   }
    avg=sum/n;
    printf("sum is %d\n",sum);
    printf("avg is %d\n",avg);

}


