#include<stdio.h>
main()
{
  int a[100],i,n;
   printf("enter the no of elements:");
   scanf("%d",&n);
   for(i=0;i<n;i++)
   {
      printf("\nenter the elements:");
     scanf("%d",&a[i]);
    }
     for(i=0;i<n;i++)
     {
     printf("\nbefore modification of  elements:%d",a[i]);
     }
     modify(a,n);
     for(i=0;i<n;i++)
     {
      printf("\nafter modification of elements:%d",a[i]);
     }
}
 void modify(int a[20],int n)
 {
  a[1]=20;
  a[3]=40;
 }













