#include<stdio.h>
#include<stdlib.h>
int main()
{ int *a;
  int n,i,m;
  printf("enter n value:");
  scanf("%d",&n);
  a=(int*)calloc(n,sizeof(int));
  for(i=0;i<n;i++)
  {
   printf("enter the elements:");
   scanf("%d",a+i);
  }
  printf("\nelements are:");
  for(i=0;i<n;i++)
  {
  printf("%d",*(a+i));
  }
  printf("\nemter new size value:");
  scanf("%d",&m);
  a=(int*)realloc(a,m*sizeof(int));
  printf("enter updated elements:");
  for(i=0;i<m;i++)
  {
    printf("\n%d",*(a+i));
  }
  for(i=n;i<m;i++)
  {
   printf("\nnwe elements are:");
   scanf("%d",a+i);
  }
  printf("\nnew updated elements are:");
  for(i=0;i<m;i++)
  {
      printf("\n%d",*(a+i));
  }
  free(a);
  printf("\n memory deallocated");
  printf("\n after deallocation ,elements are:");
  for(i=0;i<m;i++)
  {
      printf("\n%d",*(a+i));
  }
}
