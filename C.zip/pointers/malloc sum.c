#include<stdio.h>
#include<stdlib.h>
main()
{
    int *a;
    int n,i,sum=0;
    printf("\n Enter n value:");
    scanf("%d",&n);
    a=(int*)malloc(n*sizeof(int));
    for(i=0;i<n;i++)
    {
      printf("\n Enter elemenrs:");
      scanf("%d",a+i);
    }
  printf("\n Elements are:\t");
  for(i=0;i<n;i++)
  {
     printf("\n%d",*(a+i));
  }
  for(i=0;i<n;i++)
  {
      sum=sum+*(a+i);
  }
      printf("\n The Sum is:=%d",sum);

}

