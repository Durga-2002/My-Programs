#include<stdio.h>
main()
{
  int fir,sec,*p,*q,sum;
   printf("enter two integers:");
   scanf("%d%d",&fir,&sec);
   p=&fir;
   q=&sec;
   sum=*p+*q;
   printf("sum of the numbers:%d",sum);
   return 0;
}
