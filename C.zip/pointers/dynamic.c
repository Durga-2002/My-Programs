#include<stdio.h>
main()
{  int *a;
    *a=10;
    printf("%d",*a);
}
