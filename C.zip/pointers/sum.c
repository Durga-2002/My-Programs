#include<stdio.h>
main()
{
  int a=20,b=10,result;
    result=sum(&a,&b);
    printf("the sum is=%d",result);
}
 int sum(int *p,int *q)
 {
   int result;
   result=*p+*q;
   return result;


 }
