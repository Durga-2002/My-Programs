#include<stdio.h>
main()
{   int a[]={10,11};
    int* const ptr=a;
    *ptr=11;
    printf("value of ptr:%d\n",*ptr);
    printf("address pinted by ptr:%d",ptr);

    printf("address pinted by ptr:%d",ptr);








}
