#include<stdio.h>
main()
{  int a=10,b=20,c=40,d=80;
    int *p[4];
    p[0]=&a;
    p[1]=&b;
    p[2]=&c;
    p[3]=&d;
    printf("the element is:%d",p[1]);









}
