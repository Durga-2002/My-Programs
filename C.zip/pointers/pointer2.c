#include<stdio.h>
int main(void)
{
  int a;
  int *pa;
  pa=&a;
  *pa=77;
  printf("a=%d\n*pa=%d\n",a,*pa);



}
