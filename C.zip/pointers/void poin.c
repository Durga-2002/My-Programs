#include <stdio.h>
void main()
{
int a=5;
float b=23.16;
void *ptr;
ptr=&a;
printf("The value of integer variable  a is= %d\n",*( (int*) ptr) );
ptr=&b;
printf("The value of float variable is= %f\n",*( (float*) ptr) );
}
