#include<stdio.h>
main()
{
  int i,a[4]={10,20,30,40};
  int *p=a;
  p=&a[0];
  p=&a[1];
  p=&a[2];
  p=&a[3];

  printf("%d",*p+i);






}
