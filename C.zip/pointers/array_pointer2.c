#include<stdio.h>
int sum(int a[100],int n);
main()
{
  int a[100],i,n,result;
   printf("enter the no of elements:");
   scanf("%d",&n);
   for(i=0;i<n;i++)
   {
      printf("\nenter the elements:");
     scanf("%d",&a[i]);
    }
     result=sum(a,n);
     printf("the sum is=%d",result);

}
 int sum(int a[20],int n)
 {
   int i,result=0;
   for(i=0;i<n;i++)
   {
   result=result+a[i];
   }
   return result;

 }













