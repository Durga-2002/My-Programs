#include<stdio.h>
main()
{  int *a={1,2,3,4};
int *p=a+2;
printf("%d",*p);
printf("%d",*a+2);









}
