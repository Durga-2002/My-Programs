#include<stdio.h>
main()
{ int i,sum,n;
   printf("enter any number");
   scanf("%d",&n);
   for(i=1;i<=n;i++)
   {
    sum=0;
    if(i%n==0)
    sum+=i;
   }
   if(sum==i)
   printf("the given number is perfect");
   else
   printf("the given number is not a perfect");
}
