#include<stdio.h>
main()
{ int i,j,rows;
    printf("enter no of rows\n");
    scanf("%d",&rows);
    for(i=1;i<=rows;i++)
    {
      for(j=1;j<=i;j++)
      {
       printf("*");
      }
     printf("\n");
    }
}


