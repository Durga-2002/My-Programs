#include<stdio.h>
main()
{ int i,j,n,fact=0;
   printf("enter the number");
   scanf("%d",&n);
   for(i=1;i<=n;i++)
   { fact=0;
     for(j=1;j<=n;j++)
     {
      if(i%j==0)
      fact++;
     }
      if(fact==2)
      printf("%d\n",i);
   }
}
