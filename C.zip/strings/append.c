#include<stdio.h>
main()
{ char s1[10],s2[10];
  int i=0,j=0;
  printf("enter string string:");
  gets(s1);
  printf("enter second string:");
  gets(s2);

  while(s1[i]!='\0')
   i++;
  while(s2[j]!='\0')
  {
    s1[i]=s2[j];
     i++;
     j++;
  }
   s1[i]='\0';
    printf("after appending string:");
    puts(s1);
}
