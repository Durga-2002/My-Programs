#include<stdio.h>
#include<string.h>
main()
{ char str[100],upper_case[100],i=0;
     printf("enter the string:");
     gets(str);
     while(str[i]!='\0')
     { if(str[i]>='a'&&str[i]<='z')
        upper_case[i]=str[i]-32;
       else
        upper_case[i]=str[i];
        i++;
      }
      upper_case[i]='\0';
       printf("the string converted into upper case:");
       puts(upper_case);
       return 0;
}


