#include<stdio.h>
#include<string.h>
main()
{ char str[100],lower_case[100],i=0;
     printf("enter the string:");
     gets(str);
     while(str[i]!='\0')
     { if(str[i]>='A'&&str[i]<='Z')
        lower_case[i]=str[i]+32;
       else
        lower_case[i]=str[i];
        i++;
      }
      lower_case[i]='\0';
       printf("the string converted into lower case:");
       puts(lower_case);
       return 0;
}







