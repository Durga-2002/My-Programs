#include<stdio.h>
#include<string.h>
main()
{ char b[10]={'a','b','c'};
  char a[10]={'d'};
  strcat(b,a);
   printf("%s",b);
}
