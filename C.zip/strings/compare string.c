#include<stdio.h>
main()
{  char str[10],str2[10];
   int i,f=0;
   printf("enter first string:");
   gets(str);
   printf("enter second string:");
   gets(str2);
   for(i=0;str[i]!='\0'||str2[i]!='\0';i++)
   {
    if(str[i]!=str2[i])
    {
      f=1;
      break;
     }
   }
   if(f==0)
     printf("two strings are equal");
   else
     printf("two strings are not equal");
}
