#include<stdio.h>
#include<string.h>
main()
{
  int i=0,j;
  char str[100];
  char rev_str[100];
  printf("enter the string:");
  scanf("%s",str);
  j=strlen(str)-1;
  while(str[j]!='\0')
  {
   rev_str[i]=str[j];
   i++;
   j--;
  }
   printf("%s",rev_str);
}
