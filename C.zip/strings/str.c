#include<stdio.h>
#include<string.h>
main()
{
  char a[10],i=0,len;
  printf("enter the string:");
  scanf("%s",a);
  while(a[i]!='\0')
  {
   i++;
  }
  len=i;
  printf("len of the string is:%d",len);
}
