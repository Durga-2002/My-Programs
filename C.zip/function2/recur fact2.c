#include<stdio.h>
main()
{  int number,result;
     printf("enter the number:");
     scanf("%d",&number);
     result=fact(number);
     printf("%d is the factorial",result);
}
 int fact(int num)//calling function//
  {
  if(num==0)
   {
    return 1;
   }
   else
   {
    return num*fact(num-1);
   }
  }



