#include<stdio.h>
int add(int,int);
void main()
{
 int num1,num2,result;
  num1=10;
  num2=20;
  result=add(num1,num2);
  printf("sum=%d",result);
}
 int add(int a,int b)
  {
   return(a+b);
  }
