#include<stdio.h>
#include<string.h>
main()
{
  char s[10]="hello world";
    printf("%s",strlen(s));
}
