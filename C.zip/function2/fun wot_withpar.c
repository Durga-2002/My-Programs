#include<stdio.h>
void sum(int a,int b)
{
 int result;
 printf("enter the values of a and b:");
 scanf("%d %d",&a,&b);
  result=a+b;
  printf("%d\n",result);
}
 main()
 {
  int x,y;
  sum(x,y);
  printf("hello world");
 }
