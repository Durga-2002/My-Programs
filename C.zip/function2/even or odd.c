#include<stdio.h>
int iseven(int num)
{
 if(num%2!=0)
  return 1;
 else
  return 0;
}
 int main()
 {
  int num;
   printf("enter number:");
   scanf("%d",&num);
   if(iseven(num))
   {
   printf("the number is odd");
   }
   else
   {
   printf("the number is even");
   }
   return 0;
}





