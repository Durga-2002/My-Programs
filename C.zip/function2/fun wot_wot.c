#include<stdio.h>
void sum()
{
 int a,b,result;
   printf("enter the values of a and b:");
   scanf("%d %d",&a,&b);
   result=a+b;
   printf("%d\n",result);
}
 main()
 {
  sum();
  printf("hello");
 }










