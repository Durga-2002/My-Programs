#include<stdio.h>
main()
{
 int n=4;
 double result;
 result=sqrt(n);
 printf("%f",result);
}
