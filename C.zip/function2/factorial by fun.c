#include<stdio.h>
long factorial(int);
int main()
{ int num;
   long fact=1;
   printf("enter the factorial number:");
   scanf("%d",&num);
   printf("the factorial of %d is %ld",num,factorial(num));
}
long factorial(int n)
{
 int c;
  long result=1;
  for(c=1;c<=n;c++)
  result=result*c;
  return result;
}
