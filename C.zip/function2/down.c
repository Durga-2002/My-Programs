#include<stdio.h>
void main()
{ int num1,num2;
   void add(int,int);
   num1=10;
   num2=20;
     printf("num1=%d\n,num2=%d\n",num1,num2);
     add(num1,num2);
}
 void add(int a,int b)
 {
 printf("sum=%d",a+b);
 }





