#include<stdio.h>
void main()
{
 int result;
  int add();
  result=add();
  printf("sum=%d",result);
}
int add()
{
 int num1,num2;
  num1=10;
  num2=20;
  return(num1+nnum2);
}




