#include<stdio.h>
int check_prime(int);
int main()
{
  int n,result;
   printf("enter the number:");
   scanf("%d",&n);
   result=check_prime(n);
   if(result==1)
    printf("the given number is prime number");
   else
    printf("the given number is not a prime number");
}
int check_prime(int a)
{
 int c;
 for(c=2;c<=a-1;c++)
 {
  if(a%c==0)
  return 0;
 }
  return 1;
}
