int add(int a,int b)
{ int c;
   c=a+b;
   return c;
}
int mul(int a,int b)
{ int c;
   c=a*b;
   return c;
}





