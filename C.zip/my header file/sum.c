#include<stdio.h>
#include"myheader.h"
main()
{
  printf("sum=%d\n",add(10,20));

  printf("mul=%d",mul(10,20));
  return 0;

}
