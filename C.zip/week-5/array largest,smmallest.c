#include<stdio.h>
main()
{  int a[10],i,n,max,min;
   printf("enter array values");
   scanf("%d",&n);
   for(i=0;i<n;i++)
   {
    printf("enter arr[%d] : ",i);
   scanf("%d",&a[i]);
   }
    max=a[0];
    for(i=0;i<n;i++)
      {
        if(a[i]>max)
        {max=a[i];}
      }
     printf("largest number is %d\n",max);
     min=a[0];
     for(i=0;i<n;i++)
     {
       if(a[i]<min)
       {min=a[i];}
     }
     printf("smallest number is %d\n",min);
}
