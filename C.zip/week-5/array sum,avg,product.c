#include<stdio.h>
main()
{ int a[10],sum,i,n,avg,fact;
   printf("enter the array values");
   scanf("%d",&n);
   for(i=0;i<n;i++)
   {
    printf("enter arr[%d] : ",i);
    scanf("%d",&a[i]);
   }
   sum=0;
   fact=1;
   for(i=0;i<n;i++)
   {
    fact=fact*a[i];
    sum=sum+a[i];
   }
    avg=sum/n;
    printf("sum is %d\n",sum);
    printf("avg is %d\n",avg);
    printf("fact is %d",fact);
}


