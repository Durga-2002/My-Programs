#include<stdio.h>
void swap(int,int);
main()
{ int a=10,b=20;
   printf("the value of a and b before swap:");
   printf("%d %d\n",a,b);
   swap(a,b);
   printf("the values of a and b after swapping:%d %d\n",a,b);
}
  void swap(int x,int y)
  {
    int temp;
    temp=x;
    x=y;
    y=temp;
    printf("x and y values after swapping:%d %d\n",x,y);
  }






