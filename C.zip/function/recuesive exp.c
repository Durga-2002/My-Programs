#include<stdio.h>
#include<math.h>
int exp_num(int,int);
main()
{ int num1,num2,res;
    printf("enter two  numbers:");
    scanf("%d,%d",&num1,&num2);
    res=exp_num(num1,num2);
    printf("result:%d",res);
}
 int exp_num(int x,int y)
  {
   if(y==0)
   {
    return 1;
   }
   else
   {
    return(x*exp_num(x,(y-1)));
   }
  }






