#include<stdio.h>
printvalue(int);
main()
{
  int r;
   printf("enter the value:");
   scanf("%d",&r);
   printvalue(r);
}
   printvalue(int y)
   {
    printf("%d is value passed",y);
   }






