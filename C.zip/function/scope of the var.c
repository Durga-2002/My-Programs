#include<stdio.h>
main()
{
  int x=10,y=20;
    printf("%d %d\n",x,y);
    {
      int y=40;
       x++;
       y++;
       printf("%d %d\n",x,y);
    }
    printf("%d %d\n",x,y);
}
