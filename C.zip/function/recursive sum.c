#include<stdio.h>
int sum(int);
main()
{  int number,result;
     printf("enter the number:");
     scanf("%d",&number);
     result=sum(number);
     printf("%d is the sum",result);
}
 int sum(int num)
  {
  if(num!=0)
   {
    return num+sum(num-1);
   }
   else
   {
    return num;
   }
  }








