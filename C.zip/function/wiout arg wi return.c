#include<stdio.h>
#include<string.h>
int sum();
main()
{ int r;
   printf("go to function to find sum of two numbers");
   r=sum();
    printf("sum of two numbers %d",r);
}
  int sum()
  {
   int a,b,c;
     scanf("%d%d",&a,&b);
     c=a+b;
     return c;
  }












