#include<stdio.h>
int sum(int,int);
main()
{ int a,b,result;
   printf("entr two values:");
   scanf("%d%d",&a,&b);
   result=sum(a,b);
   printf("%d is sum of two numbers",result);
}
  int sum(int x,int y)
  {
    int sum;
     sum=x+y;
     return sum;
  }
