#include<stdio.h>
void printname();
main()
{
  printf("hello");
  printname();
}
 printname()
 {
  printf("rgukt");
 }







