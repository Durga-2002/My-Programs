#include<stdio.h>
#include<stdlib.h>
main()
{
   int i=1,a,b,c,e
   float=k;
   while(i<=10)
   {
    a=rand()%10;
    b=rand()%10;
    p=rand()%3;
    if(p==1)
    {
        printf("%d+%d=",i,j);
        c=a+b;
        scanf("%d",e);
        if()
    }





    }





   }



























}
