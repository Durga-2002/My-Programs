#include<stdio.h>
int gcd(int,int);
int main()
{
 int a,b,result;
  printf("enter the two numbers to find gcd:");
  scanf("%d%d",&a,&b);
  result=gcd(a,b);
  if(result==1)
  {
  printf("co prime numbers");
  }
  else
  {
  printf("not a co prime numbers");
  }
}
int gcd(int a,int b)
{
 while(a!=b)
 {
     if(a>b)
     {
         return gcd(a-b,b);
     }
     else
     {
         return gcd(a,b-a);
     }
 }
 return a;
}
