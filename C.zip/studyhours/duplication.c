#include<stdio.h>
main()
{  int a[10],i,j,n,k;
    printf("enter array size:");
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
      printf("enter the elements:");
      scanf("%d",&a[i]);
    }
    for(i=0;i<n;i++)
    {
        for(j=i+1;j<n;j++)
        {
        if(a[i]==a[j])
        {
         for(k=j;k<n;k++)
         {
             a[k]=a[k+1];
         }
         n--;
        }
        }
    }
    for(i=0;i<n;i++)
    {
    printf("%d\n",a[i]);
    }
}







