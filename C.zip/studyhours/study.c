#include<stdio.h>
main()
{
  int p=2000,t=2,r=4;
  float si;
  si=(p*t*r)/100;
  if(si>2000)
  {
   si=si+50;
  }
  else
  {
   si-=50;
  }
  printf("%f",si);
}
