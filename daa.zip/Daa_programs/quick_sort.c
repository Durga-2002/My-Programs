#include<stdio.h>
void quicksort(int [],int,int);
int main()
{
  int a[20],n,i;
  printf("Enter no.of elements: ");
  scanf("%d",&n);
  printf("Enter elements:\n");
  for(i=0;i<n;i++)
  {
	scanf("%d",&a[i]);
  }
  quicksort(a,0,n-1);
  printf("After sorting elements are:\n");
  for(i=0;i<n;i++)
  {
	printf("%d\t",a[i]);
  }
}
void quicksort(int a[],int low,int high)
{
  int pivot,temp,i,j;
  pivot=a[low];
  if(low<high)
  {
	i=low;
	j=high;
	while(i<j)
	{
		while(a[i]<=pivot)
		{
		     i++;
		}
		while(a[j]>pivot)
		{
		     j--;
		}
		if(i<j)
		{
		     temp=a[i];
		     a[i]=a[j];
		     a[j]=temp;
		}
	}
	if(j<=i)
	{
		temp=a[j];
		a[j]=a[low];
		a[low]=temp;
		quicksort(a,low,j-1);
		quicksort(a,j+1,high);
	}
   }
}
