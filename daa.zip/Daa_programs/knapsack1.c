#include<stdio.h>
int max(int a,int b)//dynamic programming
{
    return(a>b)?a:b;
}
int knap(int n,int m,int p[],int w[])
{
   int i,j;
   int a[n+1][m+1];
   for(i=0;i<=n;i++)// for tabulated values and for profit
   {
       for(j=0;j<=m;j++)
       {
           if(i==0||j==0)
           {
               a[i][j]=0;
           }
           else if(w[i]<=j)
           {
               a[i][j]=max(p[i]+a[i-1][j-w[i]],a[i-1][j]);
           }
           else
           {
               a[i][j]=a[i-1][j];
           }
       }

   }
   int c=n;
   int d=m;
   int e[10]={0};
   while(c>0&&d>0)//to identify which objects are taken for optimal solution
   {
       if(a[c][d]==a[c-1][d])
       {
           c--;
       }
       else
       {
           e[c]=c;
           d=d-w[c];
           c--;
       }
   }
   for(int y=0;y<10;y++)//for printing the required output
   {
       if(e[y]!=0)
       {
           printf("\nobject\tprofit\tweight\n");
           printf("%d\t%d\t%d\n",e[y],p[y],w[y]);
       }
   }
   return a[n][m];
}
int main()
{
   int n,m;
   printf("enter the no of objects:");
   scanf("%d",&n);
   printf("\nenter the capacity of the bag:");
   scanf("%d",&m);
   int p[n],w[n];
   printf("\nenter the profit values:");
   for(int b=1;b<=n;b++)
   {
       scanf("%d",&p[b]);
   }
   printf("\nenter the weight values:");
   for(int i=1;i<=n;i++)
   {
       scanf("%d",&w[i]);
   }
   printf("\nprofit:%d",knap(n,m,p,w));
}
