#include<stdio.h>
int min(int a,int b)
{
    return(a<b)?a:b;
}
int path(int n,int g[n][n])
{
   for(int k=1;k<=n;k++)
   {
       for(int i=1;i<=n;i++)
       {
           for(int j=1;j<=n;j++)
           {
               g[i][j]=min(g[i][j],g[i][k]+g[k][j]);
           }
       }
   }
   printf("\nThe matrix is:");
   for(int t=1;t<=n;t++)
   {
       printf("\n");
       for(int r=1;r<=n;r++)
       {
           printf("%d\t",g[t][r]);
       }
   }
}
void main()
{
    int v1,v2,w,n,e;
    printf("enter the no of vertices in the graph:");
    scanf("%d",&n);
    printf("enter the no of edges in the graph:");
    scanf("%d",&e);
    int g[n][n];
    for(int i=1;i<=n;i++)
    {
        printf("\n");
        for(int j=1;j<=n;j++)
        {
            if(i==j)
            {
              g[i][j]=0;
            }

            else
            {
                g[i][j]=999;
              //999 means infinity
            }

        }
    }
    for(int k=1;k<=e;k++)
    {
        printf("\nenter the weights between the vertices which have edges\n");
        printf("vertex 1:");
        scanf("%d",&v1);
        printf("\nvertex 2:");
        scanf("%d",&v2);
        printf("\nweight:");
        scanf("%d",&w);
        g[v1][v2]=w;
    }
    for(int t=1;t<=n;t++)
   {
       printf("\n");
       for(int r=1;r<=n;r++)
       {
           printf("%d\t",g[t][r]);
       }
   }
    path(n,g);
}
