package in.ac.rguktsklm.faculty;
class employee1
{
 public static void main(String dr[])
 {
 System.out.println("multilevel folder");
 }
}