import java.lang.*;
import java.util.Scanner;
class operate
{
 void read()
 {
  Scanner sc=new Scanner(System.in);
  System.out.println("enter first operand:");
  String n1=sc.nextLine();
  
  System.out.println("1.+,2.-,3.*,4./,5.%");
  int op=sc.nextInt();
  
  System.out.println("enter second operand:");
  String n2=sc.nextLine();


  if(n1.charAt(0)=='+'||n1.charAt(0)=='-'||n1.charAt(0)=='*'||n1.charAt(0)=='%'||n1.charAt(0)=='/'||n2.charAt(0)=='+'||n2.charAt(0)=='-'||n2.charAt(0)=='*'||n2.charAt(0)=='%'||n2.charAt(0)=='/')
  {
   System.out.println("invalid input!");
  }
  
  else
  {
    int a=Integer.parseInt(n1);
    int b=Integer.parseInt(n2);
    System.out.println(a);
    System.out.println(b);
   switch(op)
   {
    case 1:
      System.out.println("addition of two numbers is:"+ (a+b));
      break;
    case 2:
      System.out.println("subtraction of two numbers is:"+ (a-b));
      break;
    case 3:
      System.out.println("multiplication of two numbers is:"+ (a*b));
      break;
    case 4:
      if(b==0)
      {
       System.out.println("enter b value greater than zero");
       }
       else
       {
      System.out.println("division of two numbers is:"+ (a/b));
       }
      break;
    case 5:
      System.out.println("modulus of two numbers is:"+ (a%b));
      break;
    default:
      System.out.println("invalid input..");
      break;

   }
  }
 }
}
class calculator
{
  public static void main(String args[])
  {
   operate p=new operate();
   p.read();
   }
}