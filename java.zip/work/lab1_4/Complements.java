import java.lang.*;
import java.util.*;
class Compliment1
{
    void ns()
  {
   Scanner s=new Scanner(System.in);
   System.out.println("enter  number");
   int n=s.nextInt();
   int a []=new int[10];
   System.out.println("enter r values");
   int r=s.nextInt();
   int temp=n,rem=0,flag=0,c=0,r2=1;
   int c1=1,c2,r3;
   while(temp!=0)
   {
    rem=temp%10;
     if(rem>=r)
        {
     flag=1;
         }
     c++;
  temp=temp/10;
   
   }
  if(flag==1)
{
System.out.println("invalid number ");

}
else
{
 for(int i=1;i<=c;i++)
     c1=c1*(r);
 c2=((c1-1)-n);
 System.out.println(r+"'s compliment   "+(c2+1));
System.out.println((r-1)+"'s compliment   "+(c2));
}
}
}
class Complements
{
   public static void main(String args[])
{
   Compliment1 p=new Compliment1();
      p.ns(); 
}

}