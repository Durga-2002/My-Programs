import java.lang.*;
import java.util.*;
class Division
{
  public static void main(String h[])
{
  Scanner s=new Scanner(System.in);
  System.out.println("Enter any two numbers:");
  int a=s.nextInt();
  int b=s.nextInt();
  if(b==0)
  {
    System.out.println("enter valid divisor");
  }
  else
{
  int y;
  y=a%b;
  int u;
  u=a/b;
  int t=0;
  int k;
   int r=y;
int o;
 if(y==0)
  {
     System.out.println(a+"/"+b+"="+u);
  }
  else
  {
     int i;
     r=r*10;
     for(i=0;i<6;i++)
     {
       
        
        
        k=r%b;
        o=r/b;
        if(k==0)
        {
              break;
         }
         else
        {
           
           t=(t*10)+o;
        }
   }
  System.out.println(a+"/"+b+"="+u+"."+t);
  }
  
}
}
}

