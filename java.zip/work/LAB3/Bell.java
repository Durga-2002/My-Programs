import java.lang.*;
import java.util.*;
class Bell
{
 public static void main(String h[])
{
  Scanner s=new Scanner(System.in);
  System.out.println("enter the value of n:");
  int n=s.nextInt();
  int a[][]=new int[50][50];
  int i,j;
  a[0][0]=1;
  a[1][0]=1;
  for(i=0;i<n;i++)
  {
     System.out.println();
     for(j=0;j<n;j++)
      {
         if(j<=i)
         {
           if(j<i)
          {
            a[i][j+1]=a[i-1][j]+a[i][j];
           a[i+2][j]=a[i+1][j+1];
            System.out.print(a[i][j]+"\t");  
         }
         else
         {
              a[i+1][0]=a[i][j];
            System.out.print(a[i][j]+"\t");
           System.out.println();
         }
     }
   else
   {
       System.out.print(" ");
   }
}
}
System.out.println("Number of equivalence equations:"+a[n-1][n-1]);
}
}
     