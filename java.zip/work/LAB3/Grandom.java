import java.lang.*;
import java.util.*;
class Grandom
{
 public static void main(String dr[])
 {
  int op,r,c,ans;
  float f;
  int total[]={0,0,0,0};
  int correct[]={0,0,0,0};
  Scanner sc=new Scanner(System.in);
  Random rand=new Random();
  int upperbound=1000;
  System.out.println("1.Addition");
  System.out.println("2.subtraction");
  System.out.println("3.multiplication");
  System.out.println("4.division");
  System.out.println("5.summary");
  System.out.println("6.exit.");
 do
 {
  int n1=rand.nextInt(upperbound);
  int n2=rand.nextInt(upperbound);
  System.out.println("select one option:");
  op=sc.nextInt();
  switch(op)
  {
   case 1:
       c=0;
       do
       {
        System.out.println("How much is addition of "+n1+"and"+n2+"?");
       System.out.println("Enter the answer: ");
       ans=sc.nextInt(); 
       if(ans==(n1+n2))
       {
       System.out.println("correct answer...keep it up!");
          if(c==0)
             correct[0]++;
       }
       else
       {
        if(ans>=n2)
          System.out.println("please try again...");
        else if(ans<=n1)
          System.out.println("Don't lose hope..try again...");
        else
          System.out.println("No..this is not correct...");
       }
       c++;
       }while(ans!=(n1+n2));
       total[0]++;
       break;
   case 2:
       c=0;
       do
       {
        System.out.println("How much is subtraction of "+n1+"and"+n2+"?");
       System.out.println("Enter the answer: ");
       ans=sc.nextInt(); 
       if(ans==(n1-n2))
       {
       System.out.println("Excellent!");
          if(c==0)
             correct[1]++;
       }
       else
       {
        if(ans>=n2)
          System.out.println("please try again...");
        else if(ans<=n1)
          System.out.println("Don't lose hope..try again...");
        else
          System.out.println("No..this is not correct...");
       }
       c++;
       }while(ans!=(n1-n2));
       total[1]++;
       break;
   case 3:
      c=0;
       do
       {
        System.out.println("How much is multiplication of "+n1+"and"+n2+"?");
       System.out.println("Enter the answer: ");
       ans=sc.nextInt(); 
       if(ans==(n1*n2))
       {
       System.out.println("correct answer...keep it up!");
          if(c==0)
             correct[2]++;
       }
       else
       {
        if(ans>=n2)
          System.out.println("please try again...");
        else if(ans<=n1)
          System.out.println("Don't lose hope..try again...");
        else
          System.out.println("No..this is not correct...");
       }
       c++;
       }while(ans!=(n1*n2));
       total[2]++;
       break;
    case 4:
        c=0;
       do
       {
        System.out.println("How result of n1/n2 "+n1+"and"+n2+"?");
       System.out.println("Enter the answer: ");
       f=sc.nextFloat(); 
       if(f==(n1/n2))
       {
       System.out.println("correct answer...keep it up!");
          if(c==0)
             correct[3]++;
       }
       else
       {
        if(f>=n2)
          System.out.println("please try again...");
        else if(f<=n1)
          System.out.println("Don't lose hope..try again...");
        else
          System.out.println("No..this is not correct...");
       }
       c++;
       }while(f!=(n1/n2));
       total[3]++;
       break;
    case 5:
       int  count=0;
       float p;
       float add=0,sub=0,mul=0,div=0,tot;
       if(total[0]>0)
       add=(correct[0]*100/total[0]);
       if(total[1]>0)
       sub=(correct[1]*100/total[1]);
       if(total[2]>0)
       mul=(correct[2]*100/total[2]);
       if(total[3]>0)
       div=(correct[3]*100/total[3]);
       for(int i=0;i<4;i++)
       {
        if(total[i]>0)
	   count++;
       }
       if(count==0)
	System.out.println("No data found");
       else
       {
				
         tot=add+sub+mul+div;
	 p=tot/count;
	 System.out.println("Percentage of each operation");
	 if(add>0)
	   System.out.println("Percentage of each Addition: "+add);
	 if(sub>0)
	  System.out.println("Percentage of each Subtraction: "+sub);
	 if(mul>0)
	  System.out.println("Percentage of each Multiplication: "+mul);
	 if(div>0)
	   System.out.println("Percentage of each Division: "+div);	
	 if(p>=75)
	   System.out.println("Your Total Percentage is: "+p+" Good Keep It up!!!");
	 else
	   System.out.println("Your Total Percentage is: "+p+" Please approach Tutor to learn Arithmetic operations accurately");
	}
	break;
   case 6:
	System.out.println("Successfully Exited");
	break;
   default:
	System.out.println("Please Enter valid Choice ");	
	break;			
   }
  }while(op!=6);
 }
}