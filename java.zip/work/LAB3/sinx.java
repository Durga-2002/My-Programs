import java.lang.*;
import java.util.*;
class sinx1
{
  void cal()
  {
   Scanner s=new Scanner(System.in);
   System.out.println("enter x value in degrees ");
   double x=s.nextDouble();
   System.out.println("enter n value");
   int n=s.nextInt();
   double r= x*(3.14/180.0);
   double sum=r;
  int fact=1,i,sign=-1;
   for(i=3;i<=n;i=i+2)
   {
     fact=fact*i*(i-1);
     sum=sum+sign*(Math.pow(r,i)/fact);
      sign=sign*-1;
    }
  System.out.println("sin("+x+")="+sum);
   
  }

}
class sinx
{
 public static void main(String dr[])
 {
 sinx1 p=new sinx1();
 p.cal();
 }

}