import java.lang.*;
import java.util.*;
class Logx
{
   double powerofnum(double m,int n)
   {
    double t=1;
    while(n!=0)
    {
     t=t*m;
    n--;
    }
     return t; 
   }
   int fact(int z)
   {
      int f=1;
      while(z>0)
     {
       f=f*z;
       z--;
     }
      return f;
   }
   void expansion(int n,double x)
   {
     int i;
     double sum=0,s=-1;
     if(x>0)
     {
       sum=(x-1)/(x+1);
       for(i=3;i<=n;i=i+2)
       {
         sum+=(1/i)*(powerofnum(((x-1)/(x+1)),i));
       }
      System.out.println("log "+x+" = "+(2*sum));     
     }
     else if(x>1/2)
     {
        for(i=1;i<=n;i=i+2)
        {
          sum+=(1/i)*(powerofnum(((x-1)/(x)),i));
        }
      System.out.println("log "+x+" = "+sum);     
     }
    else
    {
       for(i=2;i<=n;i++)
       {
          sum+=s*(powerofnum((x-1),i)/i);
          s=s*-1;
       }
     System.out.println("log "+x+" = "+sum);
    }
  }
}
class Log
{
  public static void main(String Vk[]) 
  {
     int n=10; 
    System.out.print("Enter the  value of x : ");
    Scanner sc=new Scanner(System.in);
    double x=sc.nextDouble();
    Log o=new Log();
    o.expansion(n,x);
    }
}