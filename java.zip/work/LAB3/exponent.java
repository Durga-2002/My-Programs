import java.lang.*;
import java.util.*;
class ex
{
 void cal()
 {
  Scanner s=new Scanner(System.in);
   System.out.println("enter x value in degrees");
   double r=s.nextDouble();
   System.out.println("enter n value");
   int n=s.nextInt();
   
   double sum=1+r;
   int fact=1,i;
   for(i=2;i<=n;i++)
   {
     fact=fact*i;
     sum=sum+(Math.pow(r,i)/fact);
    }
  System.out.println("e^("+r+")="+sum);
   
  }
  
 
}
class exponent
{
 public static void main(String dr[])
 { 
  ex p=new ex();
  p.cal();
 }
}