package in.ac.rguktnuzvid;
public class ncsestud
{
 public void ncsea()
 {
  System.out.println("method a");
 }
 public void ncseb()
 {
  System.out.println("method b");
 }
 public void ncsec()
 {
  System.out.println("method c");
 }
}