import java.util.*;
public class UDE extends Exception
{
 UDE(String s)
 {
  super(s);
 }
 public static void main(String ds[])
 {
  Scanner sc=new Scanner(System.in);
  try
  {
   String rno=ds[0];
   System.out.println("enter your age:");
   int age=sc.nextInt();
   if(age<19)
   {
     throw new UDE("please enter more than 19");
   }
   System.out.println("entered age is:"+age);
   if(rno.length()!=7)
   {
     throw new UDE("enter rno correctly");
   }
   System.out.println("entered roll number is:"+rno);
  }
  catch(UDE e)
  {
   System.out.println(e.getMessage());
  }
  catch(Exception u)
  {
  System.out.println("There is a problem in the inputs given.");
  }
 }
}