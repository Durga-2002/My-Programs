import java.lang.*;
import java.util.*;
class NeatedTry
{
 public static void main(String dr[])
 {
  Scanner sc=new Scanner(System.in);
  int d[]=new int[5];
  for(int i=0;i<5;i++)
  {
  System.out.println("enter"+(i+1)+"  value:");
  d[i]=sc.nextInt();
  }
  try
  {
   try
   {
    System.out.println("division is:"+(d[4]/d[1]));
   }
   catch(ArithmeticException e)
   {
    System.out.println("denominator should not be zero.");
   }
  d[10]=20;
  }
  catch(ArrayIndexOutOfBoundsException  ae)
  {
   System.out.println("memory not sufficient");
  }
  
 }
}