import java.util.*;
class example
{
  public static void main(String dr[])
  {
   Scanner sc=new Scanner(System.in);
   System.out.println("enter value to perform division:");
   try
   {
    int x=sc.nextInt();
    int d=(535/x);
    System.out.println("value after division is:"+d);
   }
   catch(ArithmeticException e)
   {
    System.out.println("x value should be non zero value");
   }
   catch(InputMismatchException  ae)
   {
    System.out.println("x value should be non zero value");
   }
  }
}