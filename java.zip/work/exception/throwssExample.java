import java.util.*;
class throwssExample
{
 static void calculate() throws ArithmeticException
 {
  System.out.println("inside the method.");
  System.out.println(10/0);
 }
 public static void main(String dr[])
 {
  System.out.println("main method.");
  calculate();
 }
}