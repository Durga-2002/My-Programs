import java.lang.*;
import java.util.*;
class Except
{
 public static void main(String dr[])
 {
  Scanner sc=new Scanner(System.in);
  System.out.println("enter a value:");
  int a=sc.nextInt();
  System.out.println("enter b value:");
  int b=sc.nextInt();
  int d[]=new int[5];
  for(int i=0;i<5;i++)
  {
  System.out.println("enter"+(i+1)+"  value:");
  d[i]=sc.nextInt();
  }
  try
  {
   System.out.println("a/b:"+a/b); //division problem
   System.out.println("try block is executed completly.");
   System.out.println("array value is:"+d[8]); // array index out of bounds exception
  }
  catch(ArithmeticException e)
  {
   System.out.println("divided by zero error.");
  }
  catch(ArrayIndexOutOfBoundsException  ae)
  {
   System.out.println("accessing the value from out of memory.");
  }
 }
}