package p;
public class ex
{
 public void div(String s1,String s2) throws NumberFormatException,ArithmeticException
 {
  int n1=Integer.parseInt(s1);
  int n2=Integer.parseInt(s2);
  int n3=n1/n2;
  System.out.println("division of two numbers is:"+n3);
 }

}
