class UDE2
{
  public static void main(String dr[])
  {
   try
   {
    String s1=dr[0];
    FindAge f =new FindAge();
    f.decide(s1);
   }
   catch(ArrayIndexOutOfBoundsException ae)
   {
    System.out.println("please pass the value through cmd");
   }
   catch(NumberFormatException ne)
   {
    System.out.println("please enter integer value only");
   }
   catch(InvalidAge ie)
   {
    System.out.println(ie.getMessage());
   }
   catch(Exception e)
   {
    System.out.println("please give input correctly");
   }
  }
}