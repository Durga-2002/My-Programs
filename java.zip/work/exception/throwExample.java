import java.util.*;
class throwExample
{
 public static void main(String dr[])
 {
  throw new ArithmeticException("example / by zero");
 }
}