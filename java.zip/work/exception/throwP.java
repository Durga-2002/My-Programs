import p.ex;
class throwP
{
  public static void main(String dr[])
  {
  try
  {
  String s1=dr[0];
  String s2=dr[1];
  ex x=new ex();
  x.div(s1,s2);
 }
 catch(ArithmeticException ae)
 {
  System.out.println("please dont enter zero for denominator.");
  }
 catch(NumberFormatException ne)
 {
  System.out.println("please enter integer values only.");
  }
 catch(ArrayIndexOutOfBoundsException ae)
 {
  System.out.println("please pass values from cmd.");
 }
}
}