import java.lang.*;
import java.util.*;
class Marks
{
 static int d[]=new int[5];
 public static void main(String dr[])
 {
  Scanner sc=new Scanner(System.in);
  for(int i=0;i<5;i++)
  {
  System.out.println("enter"+(i+1)+"value:");
  d[i]=sc.nextInt();
  }
  System.out.println("enter the subject number to get the marks:");
  int r=sc.nextInt();
  read(r);
}
 public static void read(int r)
  {
   try
   {
    System.out.println("entered subject marks are:"+d[r-1]);
   }
   catch(ArithmeticException e)
   {
    System.out.println("Exception caught.");
   }
   catch(ArrayIndexOutOfBoundsException  ae)
   {
   System.out.println("memory not sufficient");
   }
  }
  
}