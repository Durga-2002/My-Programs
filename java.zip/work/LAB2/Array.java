import java.lang.*;
import java.util.*;
class array1
{
 void cal()
 {
  Scanner sc=new Scanner(System.in);
  System.out.println("enter number of elements:");
  int n=sc.nextInt();
  int a[]=new int[n];
  int temp[]=new int[n];
  System.out.println("enter elements:");
  for(int i=0;i<n;i++)
  {
   a[i]=sc.nextInt();
  }
  System.out.println("even numbers are followed by odd numbers:");
  for(int i=0;i<n;i++)
  {
    if(a[i]%2!=0)
    {
       System.out.println(a[i]);
     }
  }
  for(int i=0;i<n;i++)
  {
    if(a[i]%2==0)
    {
       System.out.println(a[i]);
     }
  }
  
  }


}
class Array
{
 public static void main(String dr[])
 {
  array1 r=new array1();
  r.cal();
 }
}