import java.lang.*;
import java.util.*;
class Number
{
 void fibonacci(int n)
 {
  int third;
   Scanner v=new Scanner(System.in);
   System.out.println("enter initial values");
   int first=v.nextInt();
   int second=v.nextInt();
   System.out.println("fibonacci series:");
   System.out.println(first);
   System.out.println(second);
   for(int i=2;i<n;i++)
    {
      third=first+second;
      System.out.println(third);
      first=second;
      second=third;
    }

  }
   void palindrom(int p)//palindrom number
   {
    int temp,sum=0;
     temp=p;
    while(p>0)
    {
     int r=p%10;
     sum=sum*10+r;
     p=p/10;
    }
    if(temp==sum)
      System.out.println("given number is palindrome");
    else
      System.out.println("given number is not a palindrome");
   }
   void armstrong(int a)//Armstrong number
   {
    int temp,sum=0;
     temp=a;
    while(a>0)
    {
     int r=a%10;
     sum=sum+(r*r*r);
     a=a/10;
    }
    if(temp==sum)
      System.out.println("given number is armstrong number.");
    else
      System.out.println("given number is not a armstrong number.");
   }
   void prime(int q)
   { 
     int count=0;
     for(int i=1;i<=q;i++)
     {
       if(q%i==0)
       {
        count++;
       }
     }
     if(count==2)
     {
      System.out.println("the given number is a prime number");
     }
    else
    {
     System.out.println("the given number is not a prime number");
    }
   }
   int fact(int r)
   {
     int fact=1;
     for(int i=1;i<=r;i++)
     {
      fact=fact*i;
     }
     return fact;
    }
   void strong(int w)
   {
     int temp,sum=0;
     temp=w;
     while(w>0)
     {
      int r=w%10;
      sum=sum+fact(r);
      w=w/10;
     }
     if(temp==sum)
     {
      System.out.println("given number is strong number.");
     }
     else
      {
      System.out.println("given number is not strong number.");
       }
   
    }
   

}
class numbers
{
 public static void main(String dr[])
 {
  Scanner s=new Scanner(System.in);
  System.out.println("enter number for fibonacci series:");
  int n=s.nextInt();   
  Number r=new Number();
  r.fibonacci(n);
  System.out.println("enter number to check palindrom:");
  int p=s.nextInt(); 
  r.palindrom(p);
  System.out.println("enter number to check armstrong:");
  int a=s.nextInt(); 
  r.armstrong(a);
  System.out.println("enter number to check prime or not:");
  int q=s.nextInt(); 
  r.prime(q);
  System.out.println("enter number to check strong number or not:");
  int w=s.nextInt(); 
  r.strong(w);
  
  


 }

}