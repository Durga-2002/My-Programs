//10)Write a java program to display the first character of your name (N X N length supported).
import java.lang.*;
import java.util.*;
class pattern1
{
  void cal(char c,int m)
  {
  System.out.println("first letter of name is:"+c);
  int i,k,j;
  for(i=1;i<=m;i++)
     {
      for(j=1;j<=m;j++)
      {
        if(i>1&&i<m&&j==1)
      {
          if(j==1)
            System.out.print(" * ");
          for(k=1;k<m-1;k++)
          {
          System.out.print("   ");
          }
          System.out.print(" * ");
      }
      else if((i==1&&j<m)||(i==m&&j<m)||(j==1))
      {
      System.out.print(" * ");
      }

      }
    System.out.println();
   }
  
  }

}
class pattern
{
  public static void main(String dr[])
  {
   pattern1 p=new pattern1();
   Scanner sc=new Scanner(System.in);
   System.out.println("enter your name:");
   char name=sc.nextLine().charAt(0);
   if(name=='d'||name=='D')
   {
   System.out.println("enter number rows:");
   int n=sc.nextInt();
   p.cal(name,n);
   }
   else
   {
   System.out.println("please enter sufficient data and it should be start with alphabet d only.");
   System.out.println("enter your name:");
   char name1=sc.nextLine().charAt(0);
   System.out.println("enter number rows:");
   int n1=sc.nextInt();
   p.cal(name1,n1);
   } 
  }

}