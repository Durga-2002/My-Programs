import java.lang.*;
import java.util.*;
class capitalize
{
  void cap()
  {
   Scanner sc=new Scanner(System.in);
   System.out.println("enter string:");
   String s=sc.nextLine();
   char a[]=s.toCharArray();
   for(int i=0;i<a.length;i++)
   {
    if(i==0)
      {
       a[i]=Character.toUpperCase(a[i]);
      }
    if(a[i]==' ')
    {
     a[i+1]=Character.toUpperCase(a[i+1]);
     }
   }
     
     for(int i=0;i<a.length;i++)
     {
       System.out.print(a[i]);
     }
   
  }
}
class capital
{
 public static void main(String dr[])
 {
  capitalize c=new capitalize();
  c.cap();
 }
}