import java.lang.*;
import java.util.*;
class divi
{
  void calculate()
  {
   Scanner sc=new Scanner(System.in);
   System.out.println("enter range of two values:");
   int a=sc.nextInt();
   int b=sc.nextInt();
   System.out.println("enter one number:");
   int n=sc.nextInt();
   System.out.println("following numbers are divisible by given number:");
   int count1=0;
   for(int i=a;i<=b;i++)
   {
    int count=0;
    if(i%n==0)
    {
     count++;
     count1=count1+count;
    }
    if(count!=0)
    {
     System.out.println(i);
    }
    }
    System.out.println("number of integers are divisible by given number is:"+count1);

  }

}
class division
{
 public static void main(String dr[])
 {
  divi d=new divi();
  d.calculate();
  }

}