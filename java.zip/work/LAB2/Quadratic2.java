import java.lang.*;
import java.lang.Math;
import java.util.Scanner;
class Quadratic2
{
public static void main(String[] args) 
{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter Number of quadratic equations:");
		int n=s.nextInt();
		int[][] a = new int[n][3];
                int k=1;
		for(int i=0;i<n;i++)
		{
			System.out.println("enter the quadratic equation "+k+" :");
			for(int j=0;j<3;j++)
			{
				a[i][j]=s.nextInt();
			}
                      k++;
		}
             System.out.println("Printing the total sum of the coefficients of Quadratic equations");
		int k1=2;
		for(int i=0;i<=2;i++)
		{
			int sum=0;
			for(int j=0;j<n;j++)
			{
				sum=sum+a[j][i];
			}
              
			System.out.println("sum of "+k1+" "+"coefficient:"+" "+sum);
                       k1--;
		}
 }
}