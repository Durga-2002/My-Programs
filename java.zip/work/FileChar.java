import java.io.*; 
import java.lang.*;
public class FileChar 
{ 
 public static void main(String args[]) throws Exception 
 { 
  /*FileReader f=new FileReader("employee.java"); 
  int i=f.read(); 
  while(i!=-1) 
  {  
    System.out.print((char)i);  
    i=f.read(); 
  }*/
  


 /* File f1=new File("employee.java"); 
  FileReader f=new FileReader(f1); 
  int i=f.read(); 
  while(i!=-1) 
  {  
   System.out.print((char)i);  
   i=f.read(); 
  }
  char[] ch=new char[(int)f1.length()]; //FIS->available, file ->Length 
  f.read(ch); 
  for(int k=0;k<ch.length;k++) 
  { 
   System.out.print((char)ch[k]); 
  } 
  f.close();*/



  /*FileWriter fw=new FileWriter("Age.java",true); 
  fw.write("in that java is one of the language as course"); 
  fw.flush();         
  System.out.print("successfully copied");*/


  /*File f=new File("Age.java"); 
   FileWriter fw=new FileWriter(f,true); 
   fw.write("in that java is one of the language as course"); 
   fw.flush();         
   System.out.print("successfully copied");*/



      /*FileWriter fw=new FileWriter("Age.java",true); 
      char[] ch={'r','g','u','k','t'}; 
      String s="durga vadige"; 
      //fw.write(ch,1,4); 
      fw.write(s); 
      fw.flush();         
      System.out.print("successfully copied"); 
      fw.close();*/

    
   File f=new File("Add.java"); 
   f.createNewFile();  
   FileWriter fw=new FileWriter(f); 
   fw.write("Example of File writer and reader"); 
   fw.flush(); 
   fw.close(); 
   System.out.println("written successfully"); 
   FileReader fr=new FileReader(f); 
   char[] ch=new char[(int)f.length()];
   fr.read(ch); 
   for(int k=0;k<ch.length;k++) 
   { 
    System.out.print((char)ch[k]); 
   }

 }
}