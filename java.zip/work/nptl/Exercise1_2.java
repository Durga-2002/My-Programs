import java.util.Scanner;  
public class Exercise1_2 
{
       public static void main(String args[]) 
       {
        Scanner s = new Scanner(System.in); 
        int x = s.nextInt(); 
        int y = s.nextInt();
        int z = s.nextInt();
        if(x > y && x > z)
       {
        System.out.print("maximum value:",+ x);
       }
       else
       {
        if(y > z)
         {
            System.out.print("maximum value:",+ y);
         }
        else
         {
            System.out.print("maximum value:",+ z);
         }
       }
      }
}