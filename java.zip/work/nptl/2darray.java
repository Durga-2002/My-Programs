class a2darray
{
 public static void main(String args[])
{
 int a[][]= new int [3][4];
  int i,j;
  for(i=0;i<3;i++)
  { 
   for(j=0;j<4;j++)
     {
      a[i][j] = i * j;
      }
    }
  for(i=0;i<3;i++)
  { 
   for(j=0;j<4;j++)
   System.out.print(a[i][j] + " ");
   System.out.println();
   }
    System.out.println();      
 }
} 

  
     