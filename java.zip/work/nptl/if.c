#include<stdio.h>
main()
{
    int a,b,c,max;
    printf("enter:");
    scanf("%d",&a);
    scanf("%d",&b);
    scanf("%d",&c);
    if(a>b)
    {
        max=a;
    }
    else
    {
        if(b>c)
        {
            max=b;
        }
        else
        {
            max=c;
        }
    }
    printf("max is = %d",max);
}
