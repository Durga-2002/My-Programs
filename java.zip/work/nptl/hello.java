// your first java applet
// An applet to print hello world

import java.applet.Applet;
import java.awt.Graphics;
 
public class hello extends Applet
{
  public void init()
     {
      resize(100,100);    
     }
  public void paint(Graphics g)
   {
    g.drawString("hello world",170,170);
   }
}