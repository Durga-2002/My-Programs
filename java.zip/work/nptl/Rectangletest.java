// use of init() to pass value through HTML to applet//
import java.applet.Applet;
import java.awt.Graphics;
  
public class Rectangletest extends Applet
{
 int w,x,y,z;
 public void init()
  {
   w = Integer.parseInt(getParameter ("wValue"));
   x = Integer.parseInt(getParameter ("xValue"));
   y = Integer.parseInt(getParameter ("yValue"));
   z = Integer.parseInt(getParameter ("zValue"));
  }
  public void paint( Graphics g)
  {
   g.drawRect(w, x, y, z);
   }
}
 