import java.io.*; 
public class assign1 
{ 
 public static void main(String args[]) throws Exception 
 { 
    FileReader fr=new FileReader("file1.txt"); 
    BufferedReader br=new BufferedReader(fr);
    FileReader fr1=new FileReader("file2.txt"); 
    BufferedReader br1=new BufferedReader(fr1);
    FileWriter fw=new FileWriter("output.txt",true);
    BufferedWriter bw=new BufferedWriter(fw);
    int i=0; 
    String line=br.readLine();
    String line1=br1.readLine();    
    while(i!=-1)
    {
     if(line!=null)
     {
      bw.write(line);
      bw.newLine();
      line=br.readLine();
     }
     if(line1!=null)
     {
      bw.write(line1);
      bw.newLine();
      line1=br1.readLine();
     }
    }
   System.out.print("successfully completed.");    
  }
}