import java.io.*; 
class OutputFile 
{ 
 public static void main(String args[]) throws Exception 
 { 
   /*FileOutputStream fos=new FileOutputStream("cse.txt",false); 
   fos.write('p'); 
   System.out.println("successfully written on to the file"); */
   File f=new File("cse.txt"); 
   FileOutputStream fos=new FileOutputStream(f); //override 
   //fos.write(65); 
   String s=" Cse meant for creativity"; 
   byte[] b=s.getBytes(); //convert string to byte format 
   fos.write(b); 
   System.out.println("successfully written on to the file"); 
   fos.close(); 
 } 
}
