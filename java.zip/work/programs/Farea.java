import java.lang.*;
class Circle
{
 double r,res;
 void area(double x)
 {
  r=x;
  calculate();
 }
 void calculate()
 {
  res=3.14*r*r;
  display();
 }
 void display()
 {
  System.out.println("area of circle:"+res);
 }
}
class Farea
{
 public static void main(String dr[])
 {
  if(dr.length!=1)
  {
   System.out.println("please enter only one parameter.");
  }
  else
  {
   Circle c=new Circle();
   double d=Double.parseDouble(dr[0]);
   c.area(d);
   }
 }
}