import java.lang.*;
import java.util.*;
class BC
{
 BC()
 {
 System.out.println("parent class constructor.");
 }
 BC(int a,int b)
 {
 System.out.println("parent class parameterized constructor.");
 }
}
class DC extends BC
{
 DC()
 {
  //super();
  System.out.println("derived class constructor.");
  
  
 }
 DC(int a,int b)
 { 
   super(4,6);
   System.out.println("derived class parameterized constructor.");
   
 }
}
class superConstructor
{
 public static void main(String ar[])
 {
   DC ob1=new DC();
   DC ob=new DC(5,6);
   
   
  }
}