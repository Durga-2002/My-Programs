import java.lang.*;
class Fcmd
{
  public static void main(String dr[])
  {
    if(dr.length!=2)
    {
     System.out.println("please enter two parameters.");
     }
    else
   {
  System.out.println("start of main method");
  System.out.println("0th position:"+dr[0] );
  System.out.println("0th position:"+dr[1] );
  int a=Integer.parseInt(dr[0]);
  int b=Integer.parseInt(dr[1]);
  System.out.println("addition operation over strings is:"+(dr[0]+dr[1]));
  System.out.println("addition operation over strings is:"+(a+b));
  //for(int i=0;i<dr.length;i++)
      //System.out.println(i+" index:"+dr[i]);
  System.out.println("end of main method");
  }
 }
}