class Java
{
public static void main(String args[])
{
 System.out.println("hello,world");
 System.out.println("hi...."+"durga");
}
}