import java.lang.*;
import java.util.*;
class A
{
 int i;
}
class B extends A
{
 int i;
 void m(int x,int y)
 {
  this.i=x;
  super.i=y;
 }
 void display()
 {
  System.out.println(i);
  System.out.println(super.i);
  
 }
}
class superK
{
 public static void main(String ar[])
 {
   B ob=new B();
   ob.m(22,5);
   ob.display();
 
  }
}