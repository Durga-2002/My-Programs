import java.lang.*;
class Fstatic
{
  void display()  // Rule-2
  {
   display1();
   System.out.println("display instance");
  }
  static void show()
  {
   System.out.println("show static method");
  }
  void display1()
  {
   Fstatic.show();  // Rule-4
   System.out.println("display 1 instance method");
  }
  public static void main(String dr[])
  {
   System.out.println("start of main method");
   show();   // Rule-1             
   Fstatic f=new Fstatic(); //Rule-3
   f.display();
   System.out.println("end of main method");
  }
}
