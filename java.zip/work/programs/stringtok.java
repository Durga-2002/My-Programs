import java.lang.*;
import java.util.*;
class stringtok
{
  public static void main(String dr[])
  {
   StringTokenizer st = new StringTokenizer("my name,is,durga");  
     //while (st.hasMoreTokens()) 
     //{  
         System.out.println(st.nextToken(",")); 
         //System.out.println("number of tokens:"+st.countTokens());   
        // break;
    // }
    
   }
}