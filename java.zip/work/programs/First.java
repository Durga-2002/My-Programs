import java.lang.*;
class Mul
{
 int a,b,c;
 void assign()
 {
  a=3;b=4;
 }
  void multiply()
  {
   c=a*b;
  }
  void display()
  {
  System.out.println("multiplication of two numbers:"+c);
  }
}
class Add
{
 static int a=5;
 int b=9;
 static void sum()
 {
  System.out.println("static a value is:"+a);
  Add l=new Add();
  System.out.println("instance b value is:"+l.b);
  }
  void imul()//Rule-4
  {
   Add.sum();
  }
  static void sub()//Rule-1
  {
   sum();
   }

}
class First
{
 public static void main(String D[])
 {
  System.out.println("From main method");
  Mul m=new Mul();
  m.assign();
  m.multiply();
  m.display();
  System.out.println("End of main method");
  //Add.sum();
  Add j=new Add();
  j.imul();
  Add.sub();
  } 
}
