import java.lang.*;
class First1
{
   public static void main(int x)
  {
   System.out.println("int method");
  }
   public static void main(String d[])  //program driver
  {
   System.out.println("From main method");
   main();
   System.out.println("End of main method");
  }
  public static void main(float j)
  {
   System.out.println("float method");
   main(7);
  }
  public static void main()
  {
   System.out.println("Without arguments method");
   main(8.9f);
  }
  


}