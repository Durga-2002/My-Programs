import java.lang.*;
import java.util.*;
class A
{
 final int a;
 A()
 {
  a=2;
 }
 void display1()
 {
  System.out.println("base class:");
  
 }
 final void display()
 {
  System.out.println("final method:");
 }
}
class B extends A
{
 void display1()
 {
  System.out.println("derived class:"+a);
  
 }
}
class FinalMethod
{
 public static void main(String ar[])
 {
   B ob=new B();
   ob.display();
   ob.display1();
  }
}