import java.lang.*;
import java.util.*;
class Outer
{
 int a=2;
 static int b=10;
 static class Nested
 {
  void m()
  {
   System.out.println("instance method.");
   }
   static void r()
   {
    System.out.println("static method.");
    System.out.println("static variable:"+b);
   }
   
 }
 public static void main(String dr[])
 {
  Outer.Nested.r();
  Outer.Nested ob=new Outer.Nested();
  ob.m();
  Outer ob1=new Outer();
  System.out.println("instance variable:"+ob1.a);
  
  
 }
}