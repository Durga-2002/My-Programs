import java.lang.*;
import java.util.*;
class A
{
 void display()
 {
 System.out.println("parent class method.");
 }
}
class B extends A
{
 void display()
 {
  System.out.println("derived class method.");
  super.display();
  
 }
}
class superMethod
{
 public static void main(String ar[])
 {
   B ob=new B();
   ob.display();
  }
}