Example of File writer and reader
new line d
d


cse welcomes you
cse measns computer....rgukt
d
d


cse welcomes you
cse measns computer....rguktmec
