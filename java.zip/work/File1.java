// fileInputOutputStream
import java.lang.*;
import java.io.*; 
class File1
{
 public static void main(String dr[]) throws Exception 
 {
   /* 1. read and copy into new location 
   String f=dr[0];    //command prompt
   FileInputStream fin=new FileInputStream(f);    // f is file name f not exist - raise an exception
   byte[] b=new byte[fin.available()];
   fin.read(b);                       //read and copied into byte array  
   String s=new String(b); 
   System.out.println("copying..."); 
   FileOutputStream fos=new FileOutputStream("C://Users//DURGA//Desktop//work//Add.txt"); 
   byte[] j=s.getBytes(); 
   fos.write(j);   
   System.out.println("successfully copied"); 
   fin.close();
  fos.close();*/

  /* 2.copy an image and vedio
  FileInputStream fin=new FileInputStream("rocky.jpg"); 
  //FileInputStream fin=new FileInputStream("s.mp4"); 
  byte[] b=new byte[fin.available()];
  fin.read(b);//read and copied into byte array 
  System.out.println("copying..."); 
  FileOutputStream fos=new FileOutputStream("C://Users//DURGA//Desktop//work//rock.jpg");
  //FileOutputStream fos=new FileOutputStream("C://Users//DURGA//Desktop//work//dr.mp4");
  fos.write(b);        
  System.out.println("successfully copied"); 
  fin.close(); 
  fos.close();*/


  // 3.example program
   FileInputStream fin=new FileInputStream("Add.txt");
   byte[] b=new byte[fin.available()]; 
   fin.read(b);
   System.out.println("copying..."); 
   String data=new String(b); // convert byte into string 
   String[] str=data.split(" "); 
   int word_count=str.length; 
   System.out.println("total number of words are:"+word_count);
   System.out.println("the words are:");
   for (int k=0;k<str.length ;k++ )
   {
     System.out.println(k+"."+str[k]);
   }
   int c=0; 
   for (int l=0;l<data.length();l++ ) 
   { 
     char ch=data.charAt(l); 
     if(ch=='a'|| ch=='e'|| ch=='i'||ch=='o'||ch=='u') 
     { 
      c++; 
     } 
   }
   System.out.print("the number of vowels are:"+c);
   int m=0; 
   for (int l=0;l<word_count ;l++ ) 
   { 
    String val=str[l]; 
    if(val.equals("satya")) 
       m++; 
   } 
   System.out.print("the number of satya word matches are:"+m);


  }
}