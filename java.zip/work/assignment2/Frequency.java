//Write  a  program   to  display  the  frequency  of   each  element  in  the  given  array.
import java.lang.*;
import java.util.*;
class Frequency1
{
    void frcount(int n,int a[],int freq[])
    {
     for(int i=0;i<n;i++)
     {
      int count=1;
      for(int j=i+1;j<n;j++)
      { 
       if(a[i]==a[j])
       { 
        count++;
        freq[j]=0;
        }
      }
      if(freq[i]!=0)
      { 
      freq[i]=count;
      }
     }
     System.out.println("frequency of all elements:");
      for(int i=0;i<n;i++)
      {
       if(freq[i]!=0)
       { 
       System.out.println(a[i]+"  occur "+freq[i]+"  times.");
       }
      }
    }

}
class Frequency
{ 
  public static void main(String dr[])
 {
  System.out.println("Name:V.Durga");
  System.out.println("ID:S170480");
  System.out.println("Class:CSE-2C"); 
  Scanner s=new Scanner(System.in);
  System.out.println("enter how many elements you want:");
  int n=s.nextInt();
  int a[]=new int[n];
  int freq[]=new int[n];
  System.out.println("enter elements:");
  for(int i=0;i<n;i++)
  {
   a[i]=s.nextInt();
   freq[i]=-1;
   }
   Frequency1 f=new Frequency1();
   f.frcount(n,a,freq);
  }
}