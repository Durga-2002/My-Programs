//Accept float values from cmd and display square of it.

import java.lang.*;
class Square
{
  float f,res;
  void assign(float x)
  {
   f=x;
   calculate();
  }
  void calculate()
  {
   res=f*f;
   display();
  }
  void display()
  {
   System.out.println("square of the given float value is:"+res );
  }
}
class Float1
{
 public static void main(String dr[])
 {
  System.out.println("Name:V.Durga");
  System.out.println("ID:S170480");
  System.out.println("Class:CSE-2C"); 
  if(dr.length!=1)
  {
   System.out.println("please enter only one parameter.");
  }
  else
  {
   Square c=new Square();
   float d=Float.parseFloat(dr[0]);
   c.assign(d);
   }
 }
}
