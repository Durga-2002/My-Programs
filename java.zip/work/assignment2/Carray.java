//Write   a   program   to  copy  all  elements  of   array   to  another  array.
import java.lang.*;
import java.util.*;
class Copyarray
{
 void array(int n,int a1[],int a2[])
 {
  for(int i=0;i<n;i++)
  {
    a2[i]=a1[i];
  }
  System.out.println("elements of first array:");
  for(int i=0;i<n;i++)
  {
  System.out.println(a1[i]);
  }
  System.out.println("elements copied into the second array:");
  for(int i=0;i<n;i++)
  {
  System.out.println(a2[i]);
  }
 }
}
class Carray
{
 public static void main(String dr[])
 {
  System.out.println("Name:V.Durga");
  System.out.println("ID:S170480");
  System.out.println("Class:CSE-2C"); 
  Scanner s=new Scanner(System.in);
  System.out.println("enter how many elements you want:");
  int n=s.nextInt();
  int a1[]=new int[n];
  int a2[]=new int[n];
  System.out.println("enter elements:");
  for(int i=0;i<n;i++)
   {
   a1[i]=s.nextInt();
   }
  Copyarray c=new Copyarray();
  c.array(n,a1,a2);
 }
}