//Write   a  program  to  print  Odd  and  Even  numbers   separately   from  array.
import java.lang.*;
import java.util.*;
class Fevenodd
{
 void even(int n,int a[])
 {
  System.out.println("even numbers are:");
   for(int i=0;i<n;i++)
   {
    if(a[i]%2==0)
       System.out.println(a[i]);
    }
  }
  void odd(int n,int a[])
  {
   System.out.println("odd numbers are:");
   for(int i=0;i<n;i++)
   {
    if(a[i]%2!=0)
       System.out.println(a[i]);
    }
   }
}
class Array
{
 public static void main(String dr[])
 {
  System.out.println("Name:V.Durga");
  System.out.println("ID:S170480");
  System.out.println("Class:CSE-2C"); 
  Scanner s=new Scanner(System.in);
  System.out.println("enter how many elements you want:");
  int n=s.nextInt();
  int a[]=new int[n];
  System.out.println("enter elements:");
  for(int i=0;i<n;i++)
  {
   a[i]=s.nextInt();
   }
  Fevenodd f=new Fevenodd();
  f.even(n,a);
  f.odd(n,a);

  }

}