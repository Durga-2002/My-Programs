import java.lang.*;
import java.util.*;
class Array1
{
  void display(int m,int n,int a[][],int b[][])
  {
   System.out.println("first matrix:");
   for(int i=0;i<m;i++)
   {
   for(int j=0;j<n;j++)
    {
     System.out.print(a[i][j]+" ");
    }
   System.out.println(" ");
   }
   System.out.println("second matrix:");
   for(int i=0;i<m;i++)
   {
   for(int j=0;j<n;j++)
    {
     System.out.print(b[i][j]+" ");
    }
   System.out.println(" ");
   }
  }
  void addition(int m,int n,int a[][],int b[][],int c[][])
  {
   for(int i=0;i<m;i++)
   {
   for(int j=0;j<n;j++)
    {
     c[i][j]=a[i][j]+b[i][j];
    }
   }
   System.out.println("addition of two matrix is:");
   for(int i=0;i<m;i++)
   {
   for(int j=0;j<n;j++)
    {
     System.out.print(c[i][j]+" ");
    }
   System.out.println(" ");
   }
  }
  void subtraction(int m,int n,int a[][],int b[][],int c[][])
  {
   for(int i=0;i<m;i++)
   {
   for(int j=0;j<n;j++)
    {
     c[i][j]=a[i][j]-b[i][j];
    }
   }
   System.out.println("subtraction of two matrix is:");
   for(int i=0;i<m;i++)
   {
   for(int j=0;j<n;j++)
    {
     System.out.print(c[i][j]+" ");
    }
   System.out.println(" ");
   }
  }
  void transpose(int m,int n,int a[][],int t[][])
  {
   for(int i=0;i<m;i++)
   {
   for(int j=0;j<n;j++)
    {
     t[j][i]=a[i][j];
    }
   }
   System.out.println("transpose of matrix a is:");
   for(int i=0;i<n;i++)
   {
   for(int j=0;j<m;j++)
    {
     System.out.print(t[i][j]+" ");
    }
   System.out.println(" ");
   }
  }
  void multiplication(int u,int v,int x,int y,int k[][],int l[][],int f[][])
  {
   System.out.println("first matrix:");
   for(int i=0;i<u;i++)
   {
   for(int j=0;j<v;j++)
    {
     System.out.print(k[i][j]+" ");
    }
   System.out.println(" ");
   }
   System.out.println("second matrix:");
   for(int i=0;i<x;i++)
   {
   for(int j=0;j<y;j++)
    {
     System.out.print(l[i][j]+" ");
    }
   System.out.println(" ");
   }
    if(v==x)
   {
   for(int i=0;i<u;i++)
   {
   for(int j=0;j<y;j++)
    {
    for(int s=0;s<v;s++)
     {
       f[i][j]+=k[i][s]*l[s][j];
     }
    }
   }
  }
   System.out.println("multiplication of the matrix is:");
  for(int i=0;i<u;i++)
  {
  for(int j=0;j<y;j++)
  {
  System.out.print(f[i][j]+" ");
  }
  System.out.println(" ");
  }
  int g[][]=new int[u][y];
  upper(u,y,f,g);
  lower(u,y,f,g);
  }
 void upper(int u,int y,int f[][],int g[][])
 {
  for(int j=0;j<y;j++)
   {
    for(int i=j;i>=0;i--)
    {
     g[i][j]=f[i][j];
     }
   }
   System.out.println("upper triangle elements:");
   for(int i=0;i<u;i++)
  {
  for(int j=0;j<y;j++)
  {
  System.out.print(g[i][j]+" ");
  }
  System.out.println(" ");
  }
 }
 void lower(int u,int y,int f[][],int g[][])
 {
  System.out.println("lower triangle elements:");
  for(int i=0;i<u;i++)
   {
    for(int j=0;j<y;j++)
    {
     if(i>=j)
     { 
      System.out.print(f[i][j]+" ");
     }
     else
     {
      System.out.print("0"+" ");
      }
     }
     System.out.println(" ");
   }
 }
  
}
class Marray
{
  public static void main(String dr[])
  {
  System.out.println("Name:V.Durga");
  System.out.println("ID:S170480");
  System.out.println("Class:CSE-2C"); 
  Scanner s=new Scanner(System.in);
  System.out.println("enter number of rows:");
  int m=s.nextInt();
  System.out.println("enter number of columns:");
  int n=s.nextInt();
  int a[][]=new int[m][n];
  System.out.println("enter elements in first matrix:");
  for(int i=0;i<m;i++)
  {
   for(int j=0;j<n;j++)
   {
     a[i][j]=s.nextInt();
   }
  }
  int b[][]=new int[m][n];
  int c[][]=new int[m][n];
  int t[][]=new int[n][m];
  System.out.println("enter elements in second matrix:");
  for(int i=0;i<m;i++)
  {
   for(int j=0;j<n;j++)
   { 
     b[i][j]=s.nextInt();
   }
  }
  Array1 r=new Array1();
  r.display(m,n,a,b);
  r.addition(m,n,a,b,c);
  r.subtraction(m,n,a,b,c);
  r.transpose(m,n,a,t);
  System.out.println("enter data for multiplication matrix:");
  System.out.println("enter number of rows in first matrix:");
  int u=s.nextInt();
  System.out.println("enter number of columns in first matrix:");
  int v=s.nextInt();
  System.out.println("enter number of rows in second matrix:");
  int x=s.nextInt();
  System.out.println("enter number of columns in second matrix:");
  int y=s.nextInt();
  int k[][]=new int[u][v];
  int l[][]=new int[x][y];
  System.out.println("enter elements in first matrix:");
  for(int i=0;i<u;i++)
  {
   for(int j=0;j<v;j++)
   {
     k[i][j]=s.nextInt();
   }
  }
  System.out.println("enter elements in second matrix:");
  for(int i=0;i<x;i++)
  {
   for(int j=0;j<y;j++)
   {
     l[i][j]=s.nextInt();
   }
  }
  int f[][]=new int[u][y];
  r.multiplication(u,v,x,y,k,l,f);
 }

}