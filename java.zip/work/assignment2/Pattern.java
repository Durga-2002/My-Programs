//Write  a  program  to  print  first  character  of  your  surname  [pattern].
import java.lang.*;
import java.util.*;
class Pattern1
{
  void pmethod(char c,int m)
  { 
   System.out.println("first letter of name is:"+c);
   for(int i=m;i>=1;i--)
   {
     for(int j=m;j>i;j--)
     {
      System.out.print(" ");
      }
      for(int k=1;k<(i*2);k++)
      {
        if(k>1 && k<(i*2)-1)
        {
          System.out.print(" ");
         }
        else
        {
         System.out.print("*");
        }
      }
    System.out.println();
   }
  }

}
class Pattern
{
  public static void main(String dr[])
  {
   System.out.println("Name:V.Durga");
   System.out.println("ID:S170480");
   System.out.println("Class:CSE-2C"); 
   Scanner sc=new Scanner(System.in);
   System.out.println("enter full name:");
   char name=sc.nextLine().charAt(0);
   Pattern1 p=new Pattern1();
   if(name=='v'||name=='V')
   {
   System.out.println("enter number rows:");
   int n=sc.nextInt();
   p.pmethod(name,n);
   }
   else
   {
   System.out.println("please enter sufficient data and it should be start with alphabet v only.");
   System.out.println("enter full name:");
   char name1=sc.nextLine().charAt(0);
   System.out.println("enter number rows:");
   int n1=sc.nextInt();
   p.pmethod(name1,n1);
   } 
  }
}

