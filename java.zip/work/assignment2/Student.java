//Write a program to read the student details of �Rgukt Sklm� students and display name and college.
import java.lang.*;
import java.util.*;
class Student1
{
 String  name,gender,branch;
 String id;
 int age;
 long mobile;
 double cgpa;
 static String college="Rgukt Sklm";
 Scanner sc=new Scanner(System.in);
 Student1()
 {
  System.out.println("Enter name:");
  name=sc.nextLine();
  System.out.println("Enter id:");
  id=sc.nextLine();
  System.out.println("Enter gender:");
  gender=sc.nextLine();
  System.out.println("Enter branch:");
  branch=sc.nextLine();
  System.out.println("Enter age:");
  age=sc.nextInt();
  System.out.println("Enter cgpa:");
  cgpa=sc.nextDouble();
  System.out.println("Enter mobile number:");
  mobile=sc.nextLong();
  }
  void display()
  {
   System.out.println("Name:"+name);
   System.out.println("College:"+college);
  }
}
class Student
{
  public static void main(String dr[])
  {
   System.out.println("Name:V.Durga");
   System.out.println("ID:S170480");
   System.out.println("Class:CSE-2C"); 
   Scanner sc=new Scanner(System.in);
   System.out.println("enter no of students::");
   int n=sc.nextInt();
   Student1[] s=new Student1[n];
   for(int i=0;i<n;i++)
   {
   s[i]=new Student1();
   }
   System.out.println("---------Student Details---------");
   for(int i=0;i<n;i++)
   {
   s[i].display();
   }
  }
}