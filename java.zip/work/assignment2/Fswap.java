//Write  a  program  to  swap  two  integer  values  in  three  ways.
import java.lang.*;
class Swap
{
 int t;
 void temp(int a,int b)//using temporary variable
 {
  t=a;
  a=b;
  b=t;
  System.out.println("--Using Third variable--");
  System.out.println("After swapping first integer="+a);
   System.out.println("Second integer="+b);
   wouttemp(a,b);
  }
  void wouttemp(int a,int b)//without using temporary variable
  {
   a=a+b;
   b=a-b;
   a=a-b;
   System.out.println("--Without using Third variable--");
   System.out.println("After swapping first integer="+a);
   System.out.println("Second integer="+b);
   method(a,b);
   }
   void method(int a,int b)//using bitwise operator
   {
   a=a^b;
   b=a^b;
   a=a^b;
   System.out.println("--Using bitwise operator--");
   System.out.println("After swapping first integer="+a);
   System.out.println("Second integer="+b);
   }

} 
class Fswap
{
 public static void main(String dr[])
 {
  System.out.println("Name:V.Durga");
  System.out.println("ID:S170480");
  System.out.println("Class:CSE-2C"); 
  if(dr.length!=2)
  {
   System.out.println("please enter two parameters.");
  }
  else
  {
  System.out.println("start of main method");
  int a=Integer.parseInt(dr[0]);
  int b=Integer.parseInt(dr[1]);
  System.out.println("Before swapping first integer="+a);
  System.out.println("second integer="+b);
  Swap s=new Swap();
  s.temp(a,b);
  System.out.println("End of main method");
  }
 }
}
