//Write a program to reverse the given elements and display the duplicate elements of array.
import java.lang.*;
import java.util.*;
class Reverse1
{
  void array(int n,int a1[])
  {
   System.out.println("reverse of the array is:");
   for(int i=n-1;i>=0;i--)
   {
    System.out.println(a1[i]);
   }
   duplicate(n,a1);
  }
  void duplicate(int n,int a1[])
  {
   int freq[]=new int[n];
   for(int i=0;i<n;i++)
   {
    freq[i]=-1;
   }
   for(int i=0;i<n;i++)
     {
      int count=1;
      for(int j=i+1;j<n;j++)
      { 
       if(a1[i]==a1[j])
       { 
        count++;
        freq[j]=1;
        }
      }
      if(freq[i]!=1)
      { 
      freq[i]=count;
      }
     }
     System.out.println("Duplicates elements of an array is:");
      for(int i=0;i<n;i++)
      {
       if(freq[i]!=1)
       { 
       System.out.println(a1[i]);
       }
      }
   }

}
class Reverse
{
 public static void main(String dr[])
 {
  System.out.println("Name:V.Durga");
  System.out.println("ID:S170480");
  System.out.println("Class:CSE-2C"); 
  Scanner s=new Scanner(System.in);
  System.out.println("enter how many elements you want:");
  int n=s.nextInt();
  int a1[]=new int[n];
  System.out.println("enter elements:");
  for(int i=0;i<n;i++)
  {
   a1[i]=s.nextInt();
   }
  Reverse1 r=new Reverse1();
  r.array(n,a1);
  }
}