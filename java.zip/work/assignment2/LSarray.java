import java.lang.*;
import java.util.*;
class Farray
{
 void largest(int n,int a[])
 {
   int large=a[0];
    for(int i=0;i<n;i++)
      {
        if(a[i]>large)
        {large=a[i];}
      }
     System.out.println("largest element is:"+large);
    int seclarge=a[1];
     for(int i=0;i<n;i++)
     {
      if(large!=a[i])
      {
      if(seclarge<a[i])
      {
      seclarge=a[i];
      }
      }
     }
     System.out.println("second largest element is:"+seclarge);
     
  }
 void smallest(int n,int a[])
 {
  int small=a[0];
    for(int i=0;i<n;i++)
      {
        if(a[i]<small)
        {small=a[i];}
      }
     System.out.println("smallest number is:"+small);
     int secsmall=a[1];
     for(int i=0;i<n;i++)
     {
         if(small!=a[i])
         {
      if(secsmall>a[i])
      {
      secsmall=a[i];
      }
      }
     }
    System.out.println("second smallest element:"+secsmall);
 }
}
class LSarray
{
  public static void main(String dr[])
 {
  System.out.println("Name:V.Durga");
  System.out.println("ID:S170480");
  System.out.println("Class:CSE-2C"); 
  Scanner s=new Scanner(System.in);
  System.out.println("enter how many elements you want:");
  int n=s.nextInt();
  int a[]=new int[n];
  System.out.println("enter elements:");
  for(int i=0;i<n;i++)
  {
   a[i]=s.nextInt();
  }
  Farray f=new Farray();
  f.largest(n,a);
  f.smallest(n,a);
 }

}