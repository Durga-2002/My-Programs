//Write  a  program  to  display  the  prime  numbers between  the  given  range.
import java.lang.*;
class Prime
{
 int i,j,count;
 void calculate(int a,int n)
 {
  System.out.println("prime numbers betweeen "+a+" and "+n+" are:");
  for(i=a;i<=n;i++)
   { 
     count=0;
     for(j=1;j<=n;j++)
     {
      if(i%j==0)
      count++;
     }
      if(count==2)
         System.out.println(i);
   }
 }
}
class Fprime
{
 public static void main(String dr[])
 {
  System.out.println("Name:V.Durga");
  System.out.println("ID:S170480");
  System.out.println("Class:CSE-2C"); 
  if(dr.length!=2)
  {
   System.out.println("please enter two parameter.");
  }
  else
  {
  System.out.println("start of main method");
  int a=Integer.parseInt(dr[0]);
  int n=Integer.parseInt(dr[1]);
  Prime p=new Prime();
  p.calculate(a,n);
  System.out.println("End of main method");
  }
 }
}