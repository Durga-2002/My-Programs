//Write  a  program  to  print  Fibonacci series,Factorial for a given number and check given number is Armstrong number or not and Palindrome number or not.
import java.lang.*;
import java.util.*;
class Number
{
  void fibonacci(int n)//fibonacci series
  {
   int third,first=0,second=1;
   System.out.println("fibonacci series:");
   System.out.println(first);
   System.out.println(second);
   for(int i=2;i<=n;i++)
    {
      third=first+second;
      System.out.println(third);
      first=second;
      second=third;
    }

   }
   void factorial(int f)//factorial of number
   {
     int fact=1;
    if(f<=0)
    {
    System.out.println("factorial does not exist.");
    }
    else
    {
    for(int i=1;i<=f;i++)
    {
     fact=fact*i;
    }
    System.out.println("factorial of a given number is:"+fact);
    }
   }
   void palindrom(int p)//palindrom number
   {
    int temp,sum=0;
     temp=p;
    while(p>0)
    {
     int r=p%10;
     sum=sum*10+r;
     p=p/10;
    }
    if(temp==sum)
      System.out.println("given number is palindrome");
    else
      System.out.println("given number is not a palindrome");
   }
   void armstrong(int a)//Armstrong number
   {
    int temp,sum=0;
     temp=a;
    while(a>0)
    {
     int r=a%10;
     sum=sum+(r*r*r);
     a=a/10;
    }
    if(temp==sum)
      System.out.println("given number is armstrong number.");
    else
      System.out.println("given number is not a armstrong number.");
   }
   

}
class Fnumber
{
 public static void main(String dr[])
 {
  System.out.println("Name:V.Durga");
  System.out.println("ID:S170480");
  System.out.println("Class:CSE-2C"); 
  Scanner s=new Scanner(System.in);
  System.out.println("enter number for fibonacci series:");
  int n=s.nextInt();   
  Number r=new Number();
  r.fibonacci(n);
  System.out.println("enter number for factorial:");
  int f=s.nextInt(); 
  r.factorial(f);
  System.out.println("enter number to check palindrom:");
  int p=s.nextInt(); 
  r.palindrom(p);
  System.out.println("enter number to check armstrong:");
  int a=s.nextInt(); 
  r.armstrong(a);
 }
}