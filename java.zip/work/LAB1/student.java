import java.lang.*;
import java.util.*;
class marks
{
 void cal(int a[],int n)
 {
  float sum=0;
  for(int i=0;i<n;i++)
  {
   sum=sum+a[i];
   }
   System.out.println("total number of marks:"+sum);
   float per;
   per=sum/600*100;
   System.out.println("percentage of the student:"+per + "%");
  }
}
class student
{
 public static void main(String dr[])
 {
   Scanner s=new Scanner(System.in);
   int n=6;
   int a[]=new int[n];
   System.out.println("enter marks for six subjects:");
   for(int i=0;i<n;i++)
   {
    a[i]=s.nextInt();
   }
   marks m=new marks();
   m.cal(a,n);
  }

}