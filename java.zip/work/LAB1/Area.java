import java.lang.*;
import java.util.*;
class circle
{
   void cal(int r)
   {
    double res=3.14*r*r;
    System.out.println("Area of circle is:"+res);
    }

}
class Area
{
 public static void main(String dr[])
  {
    Scanner s=new Scanner(System.in);
    System.out.println("enter radius of the circle:");
    int n=s.nextInt();
    circle c=new circle();
    c.cal(n);

   }

}