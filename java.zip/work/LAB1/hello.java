import java.lang.*;
import java.util.*;
class hello
{
   public static void main(String dr[])
   {
     System.out.println("Welcome to CSE department");
   }

}