import java.lang.*;
import java.lang.Math;
import java.util.Scanner;
class Quadratic
{
	public static void main(String[] args) 
	{
		int p=0;
		double r1,r2,img;
		Scanner s=new Scanner(System.in);
		System.out.println("Enter coefficients of quadratic equation :");
		float a=s.nextFloat();	
		float b=s.nextFloat();
		float c=s.nextFloat();
		float dis=(b*b)-(4*a*c);
		if(dis==0)
			p=0;
		else if(dis>0)
			p=1;
		else if(dis<0)
			p=-1;
		switch(p)
		{
			case 0:
			System.out.print("Equal and real roots are:");
			r1=r2=(-b)/(2*a);
			System.out.println(r1+" "+r2);
			break;
			case 1:
			System.out.print("Two real roots:");
			r1=((-b)+Math.sqrt(dis))/(2*a);
			r2=((-b)-Math.sqrt(dis))/(2*a);
			System.out.println(r1+" "+r2);
			break;
			case -1:
			r1 = r2 = -b / (2 * a);
            img=Math.sqrt(-dis)/(2 * a);
            System.out.println("complex roots:"+r1+"+i"+img+"\n"+r2+"-i"+img);
            break;
		}
	}
}