import java.lang.*;
import java.util.*;
class days1
{
 void cal(int month,int year)
 {
   if(month==1||month==3||month==5||month==7||month==8||month==10||month==12)
   {
     System.out.println("31 days");
    }
   else if(month==2)
   {
   if(year%400==0||year%4==0||year%100!=0)
   {
    System.out.println("29 days");
   }
   else
   {
    System.out.println("28 days");
   }
  }
  else
  System.out.println("30 days");
  }
}
class days
{
 public static void main(String dr[])
 {
  if(dr.length!=2)
  {
   System.out.println("please enter two parameters.");
  }
  else
  {

  System.out.println("number of days");
  int month=Integer.parseInt(dr[0]);
  int year=Integer.parseInt(dr[1]);
  days1 d=new days1();
  d.cal(month,year);
  }
 }

}