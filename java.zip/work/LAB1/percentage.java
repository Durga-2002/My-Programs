import java.lang.*;
import java.util.*;
class students
{
  void read()
  {
   Scanner sc=new Scanner(System.in);
   System.out.println("enter number of students:");
   int n=sc.nextInt();
   int a[][]=new int[n][6];
   for(int i=0;i<n;i++)
   {
    System.out.println("enter the marks for each subject of the student:");
    for(int j=0;j<6;j++)
    {
     a[i][j]=sc.nextInt();
    }
   }
   calculate(a,n);
  }
  void calculate(int a[][],int n)
  { 
    for(int i=0;i<n;i++)
    {
      int sum=0;
      for(int j=0;j<6;j++)
      {
       sum=sum+a[i][j];
      }
    System.out.println("total marks of the student:"+sum);
    float per;
     per=(sum*100)/600;
    System.out.println("percentage of the student is:"+per+"%");
    }
    
  }
  
}
class percentage
{
  public static void main(String dr[])
  {
   students s=new students();
   s.read();
  }
}