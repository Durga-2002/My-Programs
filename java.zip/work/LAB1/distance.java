import java.lang.*;
import java.util.*;
class distance
{
  public static void main(String dr[])
  {
   long speed;
   Scanner s=new Scanner(System.in);
   System.out.println("enter number of days:");
   int n=s.nextInt();
   speed=18600;
   long time;
   time=n*24*60*60;
   long dis;
   dis=speed*time;
   System.out.println("DIstance of light to the given number of days:"+dis  + "miles");
   
   }


}