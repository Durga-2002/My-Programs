package rgukt;
class employee
{
 public static void main(String dr[])
 {
 System.out.println("single level folder");
 }
}