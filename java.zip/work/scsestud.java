package in.ac.rguktsklm;
import in.ac.rguktnuzvid.*;
class scsestud
{
 public static void main(String dr[])
 {
  //in.ac.rguktnuzvid.ncsestud n=new in.ac.rguktnuzvid.ncsestud();
  ncsestud n=new ncsestud();
  n.ncsea();
  n.ncseb();
  n.ncsec();
 }
}