import java.io.*;
class InputFile
{
  public static void main(String ds[]) throws Exception
  {
   /* FileInputStream fis=new FileInputStream("employee.java"); 
    int i=0; 
    while((i=fis.read())!=-1) 
   {        
     System.out.print((char)i); 
    } */

   
    /* File f=new File("abc.txt"); 
    f.createNewFile(); 
    FileInputStream fis=new FileInputStream(f);        
    int i=0;    
    while((i=fis.read())!=-1) 
   {        
    System.out.print((char)i); 
   }*/
   
   FileInputStream fis=new FileInputStream("employee.java"); 
   byte[] b=new byte[fis.available()]; 
   fis.read(b); 
   /*for(int k=0;k<b.length;k++)   
   {  
     System.out.print((char)b[k]);
   }*/ 
   String data=new String(b); //byte array into string data 
   System.out.print(data); 
   fis.close();
   
  }

}