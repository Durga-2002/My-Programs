#include<stdio.h>
#include<stdlib.h>
struct node
{
 int  data;
 struct node *next;
 struct node *prev;
}*head=NULL;
void creat()
{
 char ch;
 do
 {
     struct node *new_node,*temp;
     new_node=(struct node*)malloc(sizeof(struct node));
     printf("\nenter the data:");
     scanf("%d",&new_node->data);
     new_node->next=NULL;
     new_node->prev=NULL;
     if(head==NULL)
     {
         head=new_node;
         temp=new_node;
     }
     else
     {
         temp->next=new_node;
         temp=new_node;
     }
 printf("\ndo what to enter the data:");
 ch=getch();
 }while(ch!='n');
}
void insert_middle()
{
  struct node *new_node,*temp;
      int pos,i;
      printf("enter position:");
      scanf("%d",&pos);
     new_node=(struct node*)malloc(sizeof(struct node));
     printf("\nenter the data:");
     scanf("%d",&new_node->data);
     new_node->next=NULL;
     if(head==NULL)
     {
         head=temp;
     }
     else
     {
        temp=head;
        for(i=1;i<pos-1;i++)
            temp=temp->next;
        new_node->next=temp->next;
        new_node->next->prev=new_node;
        temp->next=new_node;
        new_node->prev=temp;
     }
}
void display()
{
    struct node *temp;
    printf("\n The linked list is:");
    temp=head;
    while(temp!=NULL)
    {
     printf("%d--->",temp->data);
     temp=temp->next;
    }
    printf("NULL");
}
main()
{
    creat();
    insert_middle();
    display();
    getch();
}

