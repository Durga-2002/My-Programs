#include<stdio.h>
#include<stdlib.h>
struct node
{
 int  data;
 struct node *next;
}*head=NULL;
void creat()
{
 char ch;
  struct node *temp1;
 do
 {
     struct node *new_node,*temp;
     new_node=(struct node*)malloc(sizeof(struct node));
     printf("\nenter the data:");
     scanf("%d",&new_node->data);
     new_node->next=NULL;
     if(head==NULL)
     {
         head=new_node;
         temp=new_node;
     }
     else
     {
         temp->next=new_node;
         temp=new_node;
         temp->next=head;
     }
 printf("\ndo what to enter the data:");
 ch=getche();
 }while(ch!='n');
 if(head!=NULL)
     {

         temp1=head;
    while(temp1->next->data!=3)
      {
          temp1=temp1->next;
      }
      struct node *temp2=temp1->next;
      temp1->next=temp1->next->next;
      free(temp2);


     }
}
void display()
{
    struct node *temp;
    printf("\n The linked list is:");
    temp=head;
    while(temp->next!=head)
    {
     printf("%d--->",temp->data);
     temp=temp->next;
    }
    printf("%d",temp->data);
}
int main()
{
    creat();
    display();
    getch();
}




