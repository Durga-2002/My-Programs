#include<stdio.h>
#include<stdlib.h>
struct node
{
 int  data;
 struct node *next;
 struct node *prev;
}*head=NULL;
void creat()
{
 char ch;
 do
 {
     struct node *new_node,*temp;
     new_node=(struct node*)malloc(sizeof(struct node));
     printf("\nenter the data:");
     scanf("%d",&new_node->data);
     new_node->prev=NULL;
     new_node->next=NULL;
     if(head==NULL)
     {
         head=new_node;
     }
     else
     {    temp=head;
         while(temp->next!=NULL)
         temp=temp->next;
         temp->next=new_node;
         new_node->prev=temp;


     }
 printf("\ndo what to enter the data:");
 ch=getche();
 }while(ch!='n');

}
void delete_at_end()
{
  struct node *temp;
  temp=head;
  while(temp->next->next!=NULL)
  {
    temp=temp->next;
  }
    temp->next->prev=NULL;
   free(temp->next);
   temp->next=NULL;
}
void display()
{
    struct node *temp;
    printf("\n The linked list is:");
    temp=head;
    while(temp!=NULL)
    {
     printf("%d--->",temp->data);
     temp=temp->next;
    }
    printf("NULL");
}
main()
{
    creat();
    delete_at_end();
    display();
    getch();
}


