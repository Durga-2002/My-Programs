#include<stdio.h>
#include<stdlib.h>
struct node
{
 int  data;
 struct node *next;
}*head=NULL;
void creat()
{
 char ch;
 do
 {
     struct node *new_node,*temp;
     new_node=(struct node*)malloc(sizeof(struct node));
     printf("\nenter the data:");
     scanf("%d",&new_node->data);
     new_node->next=NULL;
     if(head==NULL)
     {
         head=new_node;
         temp=new_node;
     }
     else
     {
         temp->next=new_node;
         temp=new_node;
         temp->next=head;
     }
 printf("\ndo what to enter the data:");
 ch=getch();
 }while(ch!='n');
}
void insert_ending()
{
     struct node *new_node,*temp;
     new_node=(struct node*)malloc(sizeof(struct node));
     printf("\nenter the new node data:");
     scanf("%d",&new_node->data);
     new_node->next=NULL;
     if(head==NULL)
     {
         head=temp;
     }
     else
     {
      while(temp->next!=head)
      {
          temp=temp->next;
      }
          temp->next=new_node;
          new_node->next=head;


     }

}

void display()
{
    struct node *temp;
    printf("\n The linked list is:");
    temp=head;
    while(temp->next!=head)
    {
     printf("%d--->",temp->data);
     temp=temp->next;
    }
    printf("%d",temp->data);
}
int main()
{
    creat();
    insert_ending();
    display();
    getch();
}


