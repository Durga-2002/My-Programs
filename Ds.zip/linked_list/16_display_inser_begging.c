#include<stdio.h>
#include<stdlib.h>
struct node
{
 int  data;
 struct node *next;
 struct node *prev;
}*head=NULL;
void creat()
{
 char ch;
 do
 {
     struct node *new_node,*temp;
     new_node=(struct node*)malloc(sizeof(struct node));
     printf("\nenter the data:");
     scanf("%d",&new_node->data);
     new_node->prev=NULL;
     new_node->next=NULL;
     if(head==NULL)
     {
         head=new_node;
     }
     else
     {    temp=head;
         while(temp->next!=NULL)
         temp=temp->next;
         temp->next=new_node;
         new_node->prev=temp;


     }
 printf("\ndo what to enter the data:");
 ch=getche();
 }while(ch!='n');
}
void insertion_begging()
{
    struct node *new_node,*temp;
     new_node=(struct node*)malloc(sizeof(struct node));
     printf("\nenter the data:");
     scanf("%d",&new_node->data);
     new_node->next=NULL;
     new_node->prev=NULL;
     if(head==NULL)
     {
         head=temp;
     }
     else
     {
         temp=head;
         while(temp->next!=NULL)
          temp=temp->next;
          new_node->next=head;
          head->prev=new_node;
          head=new_node;
     }
}
void display()
{
    struct node *temp;
    printf("\n The linked list is:");
    temp=head;
    while(temp!=NULL)
    {
     printf("%d--->",temp->data);
     temp=temp->next;
    }
    printf("NULL");
}
main()
{
    creat();
    insertion_begging();
    display();
    getch();
}


