#include<stdio.h>
#include<stdlib.h>
struct node
{
 int  data;
 struct node *next;
 struct node *prev;
}*head=NULL;
void create()
{
 char ch;
 do
 {
     struct node *new_node,*temp;
     new_node=(struct node*)malloc(sizeof(struct node));
     printf("\nenter the data:");
     scanf("%d",&new_node->data);
     new_node->prev=NULL;
     new_node->next=NULL;
     if(head==NULL)
     {
         head=new_node;
     }
     else
     {    temp=head;
         while(temp->next!=NULL)
         temp=temp->next;
         temp->next=new_node;
         new_node->prev=temp;


     }
 printf("\ndo what to enter the data:");
 ch=getche();
 }while(ch!='n');
}
void  delete_at_starting()
{
   struct node *temp1;
   temp1=head;
   if(head!=NULL)
   head=head->next;
   head->prev=NULL;
   free(temp1);
}
void delete_at_end()
{
    struct node *temp;
  temp=head;
  if(head!=NULL)
  {
  while(temp->next->next!=NULL)
  {
    temp=temp->next;
  }
    temp->next->prev=NULL;
   free(temp->next);
   temp->next=NULL;
  }
}
void delete_at_particular()
{
    struct node *temp,*temp2;
 int i;/*,pos;*/
 printf("\nenter position:");
 scanf("%d",&i);
 temp=head;
 if(head!=NULL)
 {
 //for(i=1;i<pos-1;i++)
 while(temp->next->data!=i)
 temp=temp->next;
 temp2=temp->next;
 temp->next=temp->next->next;
 temp->next->prev=temp;
 free(temp2);
 }
}
void display()
{
    struct node *temp;
    printf("\n The linked list is:");
    temp=head;
    while(temp!=NULL)
    {
     printf("%d--->",temp->data);
     temp=temp->next;
    }
    printf("NULL");
}
main()
{
   int op;
    int select;
    printf("*********menu***********");
    printf("\n1.Display list\n2.delete at starting node\n3.delete at end\n4.delete at particular node\n5.exit");
    select:printf("\nenter your choice:");
    scanf("%d",&op);
    switch(op)
    {
  case 1:
    {create();
      display();
      getch();
    }
    goto select;
    break;

  case 2:
    {
        delete_at_starting();
        display();
    }
    goto select;
    break;
  case 3:
    {
        delete_at_end();
        display();
    }
    goto select;
    break;
  case 4:
    {
        delete_at_particular();
        display();
    }
    goto select;
    break;
  default:
    printf("exit");
    break;

   }
}


