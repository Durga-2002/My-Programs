#include<stdio.h>
#include<stdlib.h>
struct node
{
    int data;
    struct node *next;
    struct node *prev;
}*head=NULL;
void create()
{
    char ch;
    do
    {
    struct node *new_node,*temp;
    new_node=(struct node*)malloc(sizeof(struct node));
    printf("\nenter data:");
    scanf("%d",&new_node->data);
    new_node->next=NULL;
    new_node->prev=NULL;
    if(head==NULL)
    {
        head=new_node;
        head->next=head;
        head->prev=head;
    }
    else
    {
        temp=head;
        while(temp->next!=head)
            temp=temp->next;
            temp->next=new_node;
            new_node->prev=temp;
            new_node->next=head;
            head->prev=new_node;
    }
    printf("\ndo u want to create another  node:");
    ch=getche();
    }while(ch!='n');
    struct node *temp;
    if(head==NULL)
    {
        head=temp;
    }
    else
    {
       struct node *temp,*temp2;
       int i,pos;
       printf("\nenter position:");
       scanf("%d",&pos);
       temp=head;
       for(i=1;i<pos-1;i++)
      temp=temp->next;
     temp2=temp->next;
     temp->next=temp->next->next;
     temp->next->prev=temp;
     free(temp2);
    }
}
void display()
{
    struct node *temp;
    temp=head;
    printf("the CDLL is:");
    while(temp->next!=head)
    {
        printf("%d-->",temp->data);
        temp=temp->next;
    }
    printf("%d-->",temp->data);
    printf("head");
}
int main()
{
    create();
    display();
    getche();
}


