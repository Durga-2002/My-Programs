#include<stdio.h>
#include<stdlib.h>
struct node
{
 int  data;
 struct node *next;
}*head=NULL;
void creat()
{
 char ch;
 do
 {
     struct node *new_node,*temp;
     new_node=(struct node*)malloc(sizeof(struct node));
     printf("\nenter the data:");
     scanf("%d",&new_node->data);
     new_node->next=NULL;
     if(head==NULL)
     {
         head=new_node;
         temp=new_node;
     }
     else
     {
         temp->next=new_node;
         temp=new_node;
     }
 printf("\ndo what to enter the data:");
 ch=getche();
 }while(ch!='n');
}
void insert_middle(int pos)
{
    int pos1=pos;
     struct node *new_node,*temp;
     new_node=(struct node*)malloc(sizeof(struct node));
     printf("\nenter the data:");
     scanf("%d",&new_node->data);
     new_node->next=NULL;
     if(head==NULL)
     {
         head=temp;
     }
     else
     {
       int i;
       temp=head;
          for(i=1;i<pos1-1;i++)
          {
          temp=temp->next;
          }
          new_node->next=temp->next;
          temp->next=new_node;


     }
}
void display(int pos)
{
    struct node *temp;
    printf("\n The linked list is:");
    temp=head;
    int i=1;
    while(i<=pos)
    {
     printf("%d\t",temp->data);
     temp=temp->next;
     i++;
    }
    printf("NULL");
}
main()
{
    int pos;
    creat();
     printf("\nenter the position:");
     scanf("%d",&pos);
    insert_middle(pos);
    display(pos);
    getch();
}


